package dev.shiftball;

import dev.shiftball.core.BallMath;
import dev.shiftball.core.Billboard;
import dev.shiftball.core.GlowMath;
import dev.shiftball.core.LightningArcs;
import dev.shiftball.core.ShiftBallConfig;
import dev.shiftball.core.SphereMesh;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Random;

/**
 * Draws the glowing, pulsing yellow ball (three nested shells) wrapped in electricity: big beams,
 * jagged bolts with forks, flying sparks, and lightning crawling over every layer of the ball. All of
 * it uses the vanilla additive "lightning" render layer - a few thousand vertices per ball, far
 * cheaper than a particle cloud.
 */
public final class ShiftBallRenderer {
    private ShiftBallRenderer() {}

    private static final SphereMesh MESH = new SphereMesh(18, 12);
    private static final int ARC_SEGMENTS = 7;
    private static final int BEAM_SEGMENTS = 10;
    private static final int SURFACE_SEGMENTS = 9;

    public static void render(WorldRenderContext ctx) {
        List<ShiftBall> balls = ShiftBallManager.active();
        List<ShiftGlow> glows = ShiftBallManager.activeGlows();
        if (balls.isEmpty() && glows.isEmpty()) return;

        VertexConsumerProvider consumers = ctx.consumers();
        MatrixStack matrices = ctx.matrixStack();
        ClientWorld world = ctx.world();
        if (consumers == null || matrices == null || world == null) return;

        Vec3d cam = ctx.camera().getPos();
        long now = System.nanoTime();
        double maxDist2 = (double) ShiftBallConfig.maxDistance * ShiftBallConfig.maxDistance;
        VertexConsumer buf = consumers.getBuffer(RenderLayer.getLightning());
        boolean drewAnything = false;

        for (ShiftBall b : balls) {
            float age = b.ageTicks(now);
            float scale = BallMath.scale(age, b.durationTicks, ShiftBallConfig.minPulse, ShiftBallConfig.pulseHz);
            if (scale <= 0f) continue;

            // Follow the real titan so the ball always covers it, whatever its size.
            Entity e = world.getEntityById(b.entityId);
            if (e != null && e.isRemoved() && !b.keepWhenRemoved) {
                b.dead = true;
                continue;
            }
            if (e != null && !e.isRemoved()) {
                Box bb = e.getBoundingBox();
                b.lastCenter = bb.getCenter();
                String typeId = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
                Float override = ShiftBallConfig.coverOverrides.get(typeId);
                float cover = override != null
                        ? override * ShiftBallConfig.sizeMultiplier
                        : BallMath.coverRadius(bb.getLengthX(), bb.getLengthY(), bb.getLengthZ(),
                                ShiftBallConfig.coverage, ShiftBallConfig.sizeMultiplier, ShiftBallConfig.smallReach);
                b.maxRadius = Math.max(b.maxRadius, BallMath.fullRadius(cover, ShiftBallConfig.minPulse));
                if (ShiftBallConfig.debug && !b.logged) {
                    b.logged = true;
                    ShiftBallClient.LOGGER.info("Shift ball: '{}' hitbox {}x{}x{} -> covering radius {} (override: {}), peak radius {}",
                            typeId, bb.getLengthX(), bb.getLengthY(), bb.getLengthZ(), cover, override != null, b.maxRadius);
                }
            } else if (b.maxRadius <= 0f) {
                // The titan entity may arrive a moment after the spawn packet: wait up to half a
                // second for it so the ball is sized from the real hitbox, then use the fallback.
                if (age < 10f) continue;
                float cover = ShiftBallConfig.fallbackRadius * ShiftBallConfig.sizeMultiplier;
                b.maxRadius = BallMath.fullRadius(cover, ShiftBallConfig.minPulse);
                if (ShiftBallConfig.debug && !b.logged) {
                    b.logged = true;
                    ShiftBallClient.LOGGER.info("Shift ball: entity {} not found, using fallback radius {}", b.entityId, cover);
                }
            }

            float radius = b.maxRadius * scale;
            if (radius < 0.05f) continue;

            Vec3d c = b.lastCenter;
            double dx = c.x - cam.x, dy = c.y - cam.y, dz = c.z - cam.z;
            if (dx * dx + dy * dy + dz * dz > maxDist2) continue;

            matrices.push();
            matrices.translate(dx, dy, dz);
            Matrix4f m = matrices.peek().getPositionMatrix();
            float ox = (float) dx, oy = (float) dy, oz = (float) dz;

            float shellR = radius * BallMath.TESSELLATION;
            float coreR = radius * 0.60f;
            float midR = radius * 0.85f;

            // 1) Everything OUTSIDE the ball goes first. The shells write depth, so if they were
            //    drawn first they would hide this lightning from anyone inside the ball (the
            //    shifter's own view); drawn first, the translucent shells just blend over it.
            if (ShiftBallConfig.beams > 0) beams(buf, m, b, age, shellR, ox, oy, oz);
            if (ShiftBallConfig.arcs && ShiftBallConfig.arcCount > 0) radialArcs(buf, m, b, age, shellR, ox, oy, oz);
            if (ShiftBallConfig.sparks && ShiftBallConfig.sparkCount > 0) sparks(buf, m, b, age, shellR, ox, oy, oz);

            // 2) The three shells from the inside out, each with electricity crawling on its surface
            //    (so it is visible from inside as well as outside). Inner shells first so the nearer
            //    outer shell still passes the depth test. The outer shell is the one that covers the
            //    titan, so it is strong, and scaled up so the flat mesh faces never dip inside the
            //    covering radius.
            float flicker = 0.9f + 0.1f * (float) Math.sin(age * 1.7f);
            float op = ShiftBallConfig.opacity;
            int arcs = ShiftBallConfig.surfaceArcs, flashes = ShiftBallConfig.surfaceSparks;
            int innerArcs = arcs > 0 ? Math.max(1, arcs / 2) : 0;

            shell(buf, m, coreR, 1.00f, 0.97f, 0.65f, a(0.70f * flicker * op));  // white-hot core
            crawl(buf, m, b, age, coreR * 1.01f, innerArcs, flashes / 3, 11L, ox, oy, oz);
            shell(buf, m, midR, 1.00f, 0.88f, 0.22f, a(0.45f * op));             // golden middle
            crawl(buf, m, b, age, midR * 1.01f, innerArcs, flashes / 3, 23L, ox, oy, oz);
            shell(buf, m, shellR, 1.00f, 0.78f, 0.10f, a(0.60f * op));           // yellow shell
            crawl(buf, m, b, age, shellR * 1.015f, arcs, flashes, 37L, ox, oy, oz);

            matrices.pop();
            drewAnything = true;
        }

        if (!glows.isEmpty()) {
            for (ShiftGlow g : glows) {
                if (renderGlow(g, buf, matrices, world, cam, now, !ctx.camera().isThirdPerson(), maxDist2)) {
                    drewAnything = true;
                }
            }
        }

        if (drewAnything && consumers instanceof VertexConsumerProvider.Immediate immediate) {
            immediate.draw(RenderLayer.getLightning());
        }
    }

    /**
     * The preshift glow: an egg-shaped aura of three nested yellow shells around the entity's body, with
     * electricity crawling on it. It gets brighter, bigger and busier the closer the transformation is.
     */
    private static boolean renderGlow(ShiftGlow g, VertexConsumer buf, MatrixStack matrices, ClientWorld world,
                                      Vec3d cam, long now, boolean firstPerson, double maxDist2) {
        Entity e = world.getEntityById(g.entityId);
        if (e == null || e.isRemoved()) {
            g.dead = true;
            return false;
        }
        float age = g.ageTicks(now);
        float fade = GlowMath.fade(g.ticksSinceEnd(now), ShiftGlow.FADE_TICKS);
        float p = GlowMath.progress(age, g.durationTicks);
        float level = GlowMath.brightness(age, g.durationTicks) * fade * ShiftBallConfig.glowIntensity;
        // The player's own first-person camera is inside the aura: keep it a soft tint, not a blindfold.
        if (firstPerson && e == net.minecraft.client.MinecraftClient.getInstance().player) level *= 0.30f;
        if (level <= 0.01f) return false;

        // Smooth between ticks: interpolate the position, keep the hitbox shape.
        Box bb = e.getBoundingBox();
        float t = ShiftBallManager.partialTick(now);
        Vec3d offset = bb.getCenter().subtract(e.getPos());
        double cx = e.prevX + (e.getX() - e.prevX) * t + offset.x;
        double cy = e.prevY + (e.getY() - e.prevY) * t + offset.y;
        double cz = e.prevZ + (e.getZ() - e.prevZ) * t + offset.z;
        double dx = cx - cam.x, dy = cy - cam.y, dz = cz - cam.z;
        if (dx * dx + dy * dy + dz * dz > maxDist2) return false;

        float grow = 1f + 0.18f * p;
        float rx = (float) (Math.max(bb.getLengthX(), bb.getLengthZ()) * 0.5 * 1.5 + 0.10) * grow;
        float ry = (float) (bb.getLengthY() * 0.5 * 1.12 + 0.10) * grow;

        matrices.push();
        matrices.translate(dx, dy, dz);
        Matrix4f m = matrices.peek().getPositionMatrix();
        float ox = (float) dx, oy = (float) dy, oz = (float) dz;

        // Electricity first (it is outside the shells), then the shells from the inside out.
        long step = (long) age;
        int bolts = Math.round(7f * Math.min(1f, level));
        float glowW = Math.max(0.03f, 0.035f * Math.min(1.5f, level));
        float coreW = glowW * 0.4f;
        for (int i = 0; i < bolts; i++) {
            long seed = g.seed * 29L + i * 7907L + step * 104729L;
            Random gate = new Random(seed ^ 0x9E3779B97F4A7C15L);
            if (gate.nextFloat() < 0.25f) continue;
            float[] pts = LightningArcs.arc(seed, 1.0f, 0.30f + 0.35f * gate.nextFloat(), 6);
            polyline(buf, m, stretch(pts, rx, ry, rx), ox, oy, oz, glowW, coreW);
        }
        int crawlers = Math.round(6f * Math.min(1f, level));
        for (int i = 0; i < crawlers; i++) {
            long seed = g.seed * 43L + i * 6113L + step * 130363L;
            if (new Random(seed ^ 0x2545F4914F6CDD1DL).nextFloat() < 0.2f) continue;
            polyline(buf, m, stretch(LightningArcs.surfaceArc(seed, 1.04f, 8), rx, ry, rx), ox, oy, oz,
                    glowW * 0.8f, coreW * 0.8f);
        }

        float lv = Math.min(1.5f, level);
        ellipsoid(buf, m, rx * 1.55f, ry * 1.30f, rx * 1.55f, 1.00f, 0.80f, 0.12f, a(0.13f * lv));  // wide yellow halo
        ellipsoid(buf, m, rx * 1.25f, ry * 1.15f, rx * 1.25f, 1.00f, 0.88f, 0.25f, a(0.20f * lv));  // golden middle
        ellipsoid(buf, m, rx, ry, rx, 1.00f, 0.97f, 0.65f, a(0.28f * lv));                          // bright inner skin

        matrices.pop();
        return true;
    }

    /** Scales a polyline (unit-sphere based) into an egg shape around the body. */
    private static float[] stretch(float[] pts, float sx, float sy, float sz) {
        float[] out = new float[pts.length];
        for (int i = 0; i + 2 < pts.length; i += 3) {
            out[i] = pts[i] * sx;
            out[i + 1] = pts[i + 1] * sy;
            out[i + 2] = pts[i + 2] * sz;
        }
        return out;
    }

    /** Like {@link #shell} but with separate radii per axis, so it can wrap a tall body. */
    private static void ellipsoid(VertexConsumer buf, Matrix4f m, float rx, float ry, float rz,
                                  float cr, float cg, float cb, float ca) {
        float[] q = MESH.quads;
        for (int i = 0; i < MESH.quadCount; i++) {
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                vertex(buf, m, q[o + k * 3] * rx, q[o + k * 3 + 1] * ry, q[o + k * 3 + 2] * rz, cr, cg, cb, ca);
            }
            for (int k = 3; k >= 0; k--) {
                vertex(buf, m, q[o + k * 3] * rx, q[o + k * 3 + 1] * ry, q[o + k * 3 + 2] * rz, cr, cg, cb, ca);
            }
        }
    }

    private static float a(float alpha) {
        return Math.min(1f, Math.max(0f, alpha));
    }

    /** Emits a sphere shell with both windings so it is visible from inside (the shifter's own view). */
    private static void shell(VertexConsumer buf, Matrix4f m, float r, float cr, float cg, float cb, float ca) {
        float[] q = MESH.quads;
        for (int i = 0; i < MESH.quadCount; i++) {
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                vertex(buf, m, q[o + k * 3] * r, q[o + k * 3 + 1] * r, q[o + k * 3 + 2] * r, cr, cg, cb, ca);
            }
            for (int k = 3; k >= 0; k--) {
                vertex(buf, m, q[o + k * 3] * r, q[o + k * 3 + 1] * r, q[o + k * 3 + 2] * r, cr, cg, cb, ca);
            }
        }
    }

    /** Big thick beams of electricity reaching far out around the ball, with forks. Re-rolled every 2 ticks. */
    private static void beams(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float shellR,
                              float ox, float oy, float oz) {
        long step = (long) (age / 2f);
        float glow = Math.max(0.14f, shellR * 0.030f * ShiftBallConfig.arcWidth);
        float core = Math.max(0.05f, shellR * 0.011f * ShiftBallConfig.arcWidth);

        for (int i = 0; i < ShiftBallConfig.beams; i++) {
            long seed = b.seed * 41L + i * 8191L + step * 15485863L;
            Random gate = new Random(seed ^ 0x9E3779B97F4A7C15L);
            if (gate.nextFloat() < 0.15f) continue;
            float length = shellR * ShiftBallConfig.beamReach * (0.7f + 0.6f * gate.nextFloat());
            float[] pts = LightningArcs.arc(seed, shellR, length, BEAM_SEGMENTS);
            polyline(buf, m, pts, ox, oy, oz, glow, core);
            for (int f = 0; f < 2; f++) {
                float[] fork = LightningArcs.branch(seed + 1L + f, pts, 3 + f * 3, length * 0.4f, 4);
                polyline(buf, m, fork, ox, oy, oz, glow * 0.6f, core * 0.6f);
            }
        }
    }

    /** Shorter jagged bolts shooting out of the ball, some with a fork. Re-rolled every ~1.5 ticks to flicker. */
    private static void radialArcs(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float shellR,
                                   float ox, float oy, float oz) {
        long step = (long) (age / 1.5f);
        float glow = Math.max(0.06f, shellR * 0.016f * ShiftBallConfig.arcWidth);
        float core = Math.max(0.025f, shellR * 0.006f * ShiftBallConfig.arcWidth);

        for (int i = 0; i < ShiftBallConfig.arcCount; i++) {
            long seed = b.seed * 31L + i * 7919L + step * 104729L;
            Random gate = new Random(seed ^ 0x5DEECE66DL);
            if (gate.nextFloat() < 0.2f) continue; // random dropouts so it crackles
            float length = shellR * ShiftBallConfig.arcReach * (0.5f + 0.7f * gate.nextFloat());
            float[] pts = LightningArcs.arc(seed, shellR, length, ARC_SEGMENTS);
            polyline(buf, m, pts, ox, oy, oz, glow, core);
            if (gate.nextFloat() < 0.6f) {
                int idx = 2 + gate.nextInt(3);
                float[] fork = LightningArcs.branch(seed + 1L, pts, idx, length * 0.45f, 4);
                polyline(buf, m, fork, ox, oy, oz, glow * 0.7f, core * 0.7f);
            }
        }
    }

    /**
     * Electricity on one layer of the ball: long bolts crawling over the surface plus tiny flashes
     * blinking on it. Re-rolled every tick so it crackles.
     */
    private static void crawl(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float r,
                              int arcCount, int flashCount, long salt, float ox, float oy, float oz) {
        long step = (long) age;
        float glow = Math.max(0.04f, r * 0.011f * ShiftBallConfig.arcWidth);
        float core = Math.max(0.018f, r * 0.0045f * ShiftBallConfig.arcWidth);

        for (int i = 0; i < arcCount; i++) {
            long seed = b.seed * 37L + salt * 6151L + i * 7727L + step * 130363L;
            if (new Random(seed ^ 0x2545F4914F6CDD1DL).nextFloat() < 0.15f) continue;
            polyline(buf, m, LightningArcs.surfaceArc(seed, r, SURFACE_SEGMENTS), ox, oy, oz, glow, core);
        }
        for (int i = 0; i < flashCount; i++) {
            long seed = b.seed * 53L + salt * 3571L + i * 9973L + step * 49979687L;
            if (new Random(seed ^ 0x1B873593L).nextFloat() < 0.4f) continue; // blink on/off
            polyline(buf, m, LightningArcs.surfaceArc(seed, r, 2), ox, oy, oz, glow * 0.85f, core * 0.85f);
        }
    }

    /** Small sparks that fly off the ball and fade out; each loops through its own short life. */
    private static void sparks(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float shellR,
                               float ox, float oy, float oz) {
        float half = Math.max(0.04f, shellR * 0.0045f * ShiftBallConfig.arcWidth);
        for (int i = 0; i < ShiftBallConfig.sparkCount; i++) {
            Random r = new Random(b.seed * 17L + i * 104729L);
            float life = 8f + 10f * r.nextFloat();      // ticks
            float x = age + r.nextFloat() * life;
            long cycle = (long) (x / life);
            float t = (x - cycle * life) / life;
            float[] sp = LightningArcs.spark(b.seed * 131L + i * 7727L + cycle * 104729L, shellR, t);
            float alpha = a(0.95f * (1f - t));
            strip(buf, m, sp[0], sp[1], sp[2], sp[3], sp[4], sp[5], ox, oy, oz, half,
                    1.00f, 0.96f, 0.65f, alpha);
        }
    }

    /** Draws a polyline twice: a wide yellow glow and a thin white-hot core. */
    private static void polyline(VertexConsumer buf, Matrix4f m, float[] pts, float ox, float oy, float oz,
                                 float glowHalf, float coreHalf) {
        int segs = pts.length / 3 - 1;
        for (int k = 0; k < segs; k++) {
            float px = pts[k * 3], py = pts[k * 3 + 1], pz = pts[k * 3 + 2];
            float qx = pts[k * 3 + 3], qy = pts[k * 3 + 4], qz = pts[k * 3 + 5];
            strip(buf, m, px, py, pz, qx, qy, qz, ox, oy, oz, glowHalf, 1.00f, 0.88f, 0.25f, 0.55f);
            strip(buf, m, px, py, pz, qx, qy, qz, ox, oy, oz, coreHalf, 1.00f, 1.00f, 0.90f, 1.00f);
        }
    }

    /**
     * A camera-facing strip between two points (ball-local). The lightning layer culls back faces,
     * so both windings are emitted (see Billboard) - one of them always faces the camera.
     */
    private static void strip(VertexConsumer buf, Matrix4f m,
                              float px, float py, float pz, float qx, float qy, float qz,
                              float ox, float oy, float oz, float half,
                              float cr, float cg, float cb, float ca) {
        float[] v = Billboard.strip(px, py, pz, qx, qy, qz, ox, oy, oz, half);
        if (v == null) return;
        for (int i = 0; i < 8; i++) {
            vertex(buf, m, v[i * 3], v[i * 3 + 1], v[i * 3 + 2], cr, cg, cb, ca);
        }
    }

    private static void vertex(VertexConsumer buf, Matrix4f m, float x, float y, float z,
                               float r, float g, float bl, float a) {
        buf.vertex(m, x, y, z).color(r, g, bl, a);
    }
}
