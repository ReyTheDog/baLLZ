package dev.shiftball.core;

/** How bright the preshift glow is. Pure Java so it can be tested without Minecraft. */
public final class GlowMath {
    private GlowMath() {}

    /** Share of the way to the transformation, 0..1. */
    public static float progress(float ageTicks, float durationTicks) {
        if (durationTicks <= 0f) return 1f;
        return Math.max(0f, Math.min(1f, ageTicks / durationTicks));
    }

    /** Smooth brightness without flicker: faint at the start, full at the transformation. Never decreases. */
    public static float base(float ageTicks, float durationTicks) {
        float p = progress(ageTicks, durationTicks);
        return 0.10f + 0.90f * (float) Math.pow(p, 1.5);
    }

    /** Brightness with a heartbeat-like pulse that speeds up as the transformation gets closer. */
    public static float brightness(float ageTicks, float durationTicks) {
        float p = progress(ageTicks, durationTicks);
        float pulse = 1f + 0.12f * (float) Math.sin(ageTicks * (0.5f + 1.5f * p));
        return Math.max(0f, Math.min(1.2f, base(ageTicks, durationTicks) * pulse));
    }

    /** Quick fade-out once the effect is over; 1 while running, 0 after {@code fadeTicks}. */
    public static float fade(float ticksSinceEnd, float fadeTicks) {
        if (ticksSinceEnd <= 0f) return 1f;
        if (ticksSinceEnd >= fadeTicks) return 0f;
        return 1f - ticksSinceEnd / fadeTicks;
    }
}
