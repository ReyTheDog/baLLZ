# Danny's AoT - Titan Shift Ball (addon)

Client-side Fabric 1.21.1 addon for Danny's AoT (tested against the class layout of 2.5.2).
Replaces the shifter transformation cloud with a glowing yellow ball that keeps shrinking and
growing, sized to the titan so it always covers it. The mod's own yellow lightning bolts, sounds
and camera are untouched; thin yellow lightning arcs are added around the ball.

## Build the jar (needs internet and JDK 21, nothing else)
**On a Mac:** `brew install openjdk@21`, then in this folder (Terminal):
`export JAVA_HOME=$(/usr/libexec/java_home -v 21) && ./gradlew build`
**On Windows:** install JDK 21, then `gradlew.bat build`.

The jar is `build/libs/dannys-aot-shiftball-1.0.0.jar` (not the `-sources` one). Put it in your
`mods` folder next to Danny's AoT. It is client-only; servers do not need it.

**No JDK? Let GitHub build it:** push this folder to a GitHub repo; the included workflow
(`.github/workflows/build.yml`) builds it, and the jar appears under Actions > the run > Artifacts.

If a version in `gradle.properties` does not resolve, take the current 1.21.1 values from
https://fabricmc.net/develop/ .

## Config
`config/dannys-aot-shiftball.properties` (created on first launch). Main options:
- `replaceCloud` - hide the original AAA-Particles shift cloud (default true)
- `coverage`, `sizeMultiplier` - the ball is never smaller than the smallest sphere containing the
  titan's whole hitbox times these; raise them if any part of a titan sticks out
- `opacity` - how strongly the ball hides the titan (raise to 1.5 for a more solid look)
- `smallReach` - small titans (Cart, Jaw, small pure titans) are low, wide bodies in thin hitboxes, so
  their hitbox is widened by this fraction of their height per side before sizing (default 0.45)
- `coverRadius.<entity_id>=<blocks>` - exact covering radius for one titan, e.g.
  `coverRadius.cart_shifter_titan=5.0` or `coverRadius.test_shifter_titan=5.5` (the Jaw shifter uses
  the mod's test_shifter_titan entity)
- `minPulse`, `pulseHz` - how far and how fast it shrinks and grows (it only ever shrinks down to
  the covering size, and swells above it)
- `arcs`, `arcCount`, `arcWidth`, `arcReach` - lightning bolts shooting out of the ball (with forks)
- `surfaceArcs` - lightning crawling over the surface of the ball
- `sparks`, `sparkCount` - little sparks flying off the ball
- `includePureTitans`, `pureTitanDuration` - the ball when a villager turns into a pure titan
- `includeColossal` - Colossal keeps its own nuke effect by default
- An older config file is replaced by the new defaults once (`configVersion`).
- `debug` - logs the ball radius per shift

## How it works
- Mixin on `daot.TitanShiftSoundHandler#onTitanSpawn` (the client handler for the mod's
  `TitanSpawnPayload`) starts a ball bound to the titan's entity id.
- Mixin on `daot.VillagerTransformEffectHandler#onTitanSpawnFromVillager` does the same when a
  villager turns into a pure titan (the 40-tick preshift glow on the villager is left alone).
- Mixin on `daot.ShiftParticleHelper#spawnShiftParticle` cancels the cloud, but only while one of those
  two handlers is running, so nothing else that uses the helper is affected.
- The ball is drawn after entities with the vanilla additive lightning render layer: three
  nested shells plus arcs, a few thousand vertices instead of a particle cloud.
- Lifetime is 80 ticks (95 for Colossal), the same as the mod's transformation timer.
- Coverage: the ball is centred on the titan's hitbox and its smallest size is the sphere that
  contains the whole hitbox (+10%). It is at that size ~6 ticks in, stays at or above it until the
  last 12% of the shift, then collapses to reveal the titan. `CoreCheck` verifies this for every
  shifter titan hitbox in Danny's AoT 2.5.2, including the flat faces of the mesh.

## Maintenance
The mixins target the mod's classes by name. If a Danny's AoT update renames
`TitanShiftSoundHandler.onTitanSpawn`, `VillagerTransformEffectHandler.onTitanSpawnFromVillager` or
`ShiftParticleHelper.spawnShiftParticle`, the game will
stop at launch with a mixin error; the addon needs a small update then.

## Checks
`src/test/java/dev/shiftball/core/CoreCheck.java` tests the pure math (pulse shape, sphere mesh,
arcs, config) with plain `javac` + `java`, no Minecraft needed.

Danny's AoT is All Rights Reserved. This addon contains none of its code or assets; consider
letting the author know before publishing it.
