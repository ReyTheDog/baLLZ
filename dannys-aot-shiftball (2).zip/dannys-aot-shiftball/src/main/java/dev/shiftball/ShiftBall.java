package dev.shiftball;

import net.minecraft.util.math.Vec3d;

/** One active transformation ball. Client thread only. */
final class ShiftBall {
    final int entityId;
    final Vec3d fallbackCenter;
    final long startNanos;
    final float durationTicks;
    final long seed;

    /** Largest radius seen so far, so the ball never shrinks below the titan while it emerges. */
    float maxRadius = 0f;
    Vec3d lastCenter;
    boolean dead = false;
    boolean logged = false;

    ShiftBall(int entityId, Vec3d fallbackCenter, float durationTicks, long seed) {
        this.entityId = entityId;
        this.fallbackCenter = fallbackCenter;
        this.lastCenter = fallbackCenter;
        this.durationTicks = durationTicks;
        this.seed = seed;
        this.startNanos = System.nanoTime();
    }

    float ageTicks(long nowNanos) {
        return (nowNanos - startNanos) / 50_000_000f;
    }
}
