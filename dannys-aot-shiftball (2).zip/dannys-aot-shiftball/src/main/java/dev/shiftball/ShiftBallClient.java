package dev.shiftball;

import dev.shiftball.core.ShiftBallConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShiftBallClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("dannys-aot-shiftball");

    @Override
    public void onInitializeClient() {
        ShiftBallConfig.load(FabricLoader.getInstance().getConfigDir().resolve("dannys-aot-shiftball.properties"));
        WorldRenderEvents.AFTER_ENTITIES.register(ShiftBallRenderer::render);
        ClientTickEvents.END_CLIENT_TICK.register(client -> ShiftBallManager.tick());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ShiftBallManager.clear());
        LOGGER.info("Titan Shift Ball loaded (enabled={}, replaceCloud={})",
                ShiftBallConfig.enabled, ShiftBallConfig.replaceCloud);
    }
}
