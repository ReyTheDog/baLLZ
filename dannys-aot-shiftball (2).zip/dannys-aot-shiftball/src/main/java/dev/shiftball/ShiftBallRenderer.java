package dev.shiftball;

import dev.shiftball.core.BallMath;
import dev.shiftball.core.LightningArcs;
import dev.shiftball.core.ShiftBallConfig;
import dev.shiftball.core.SphereMesh;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Random;

/**
 * Draws the glowing, pulsing yellow ball (three nested shells) with crackling lightning around it
 * (bolts with forks, lightning crawling over the surface, and flying sparks), all with the vanilla
 * additive "lightning" render layer. A few thousand vertices per ball - far cheaper than a particle cloud.
 */
public final class ShiftBallRenderer {
    private ShiftBallRenderer() {}

    private static final SphereMesh MESH = new SphereMesh(18, 12);
    private static final int ARC_SEGMENTS = 7;
    private static final int SURFACE_SEGMENTS = 9;

    public static void render(WorldRenderContext ctx) {
        List<ShiftBall> balls = ShiftBallManager.active();
        if (balls.isEmpty()) return;

        VertexConsumerProvider consumers = ctx.consumers();
        MatrixStack matrices = ctx.matrixStack();
        ClientWorld world = ctx.world();
        if (consumers == null || matrices == null || world == null) return;

        Vec3d cam = ctx.camera().getPos();
        long now = System.nanoTime();
        double maxDist2 = (double) ShiftBallConfig.maxDistance * ShiftBallConfig.maxDistance;
        VertexConsumer buf = consumers.getBuffer(RenderLayer.getLightning());
        boolean drewAnything = false;

        for (ShiftBall b : balls) {
            float age = b.ageTicks(now);
            float scale = BallMath.scale(age, b.durationTicks, ShiftBallConfig.minPulse, ShiftBallConfig.pulseHz);
            if (scale <= 0f) continue;

            // Follow the real titan so the ball always covers it, whatever its size.
            Entity e = world.getEntityById(b.entityId);
            if (e != null) {
                if (e.isRemoved()) {
                    b.dead = true;
                    continue;
                }
                Box bb = e.getBoundingBox();
                b.lastCenter = bb.getCenter();
                String typeId = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
                Float override = ShiftBallConfig.coverOverrides.get(typeId);
                float cover = override != null
                        ? override * ShiftBallConfig.sizeMultiplier
                        : BallMath.coverRadius(bb.getLengthX(), bb.getLengthY(), bb.getLengthZ(),
                                ShiftBallConfig.coverage, ShiftBallConfig.sizeMultiplier, ShiftBallConfig.smallReach);
                b.maxRadius = Math.max(b.maxRadius, BallMath.fullRadius(cover, ShiftBallConfig.minPulse));
                if (ShiftBallConfig.debug && !b.logged) {
                    b.logged = true;
                    ShiftBallClient.LOGGER.info("Shift ball: titan '{}' hitbox {}x{}x{} -> covering radius {} (override: {}), peak radius {}",
                            typeId, bb.getLengthX(), bb.getLengthY(), bb.getLengthZ(), cover, override != null, b.maxRadius);
                }
            } else if (b.maxRadius <= 0f) {
                // The titan entity may arrive a moment after the spawn packet: wait up to half a
                // second for it so the ball is sized from the real hitbox, then use the fallback.
                if (age < 10f) continue;
                float cover = ShiftBallConfig.fallbackRadius * ShiftBallConfig.sizeMultiplier;
                b.maxRadius = BallMath.fullRadius(cover, ShiftBallConfig.minPulse);
                if (ShiftBallConfig.debug && !b.logged) {
                    b.logged = true;
                    ShiftBallClient.LOGGER.info("Shift ball: titan entity {} not found, using fallback radius {}", b.entityId, cover);
                }
            }

            float radius = b.maxRadius * scale;
            if (radius < 0.05f) continue;

            Vec3d c = b.lastCenter;
            double dx = c.x - cam.x, dy = c.y - cam.y, dz = c.z - cam.z;
            if (dx * dx + dy * dy + dz * dz > maxDist2) continue;

            matrices.push();
            matrices.translate(dx, dy, dz);
            Matrix4f m = matrices.peek().getPositionMatrix();

            // Inner shells are drawn first so the nearer outer shell still passes the depth test.
            // The outer shell is the one that must cover the titan, so it is strong, and scaled up
            // slightly so the flat faces of the mesh never dip inside the covering radius.
            float flicker = 0.9f + 0.1f * (float) Math.sin(age * 1.7f);
            float op = ShiftBallConfig.opacity;
            float shellR = radius * BallMath.TESSELLATION;
            shell(buf, m, radius * 0.60f, 1.00f, 0.97f, 0.65f, a(0.70f * flicker * op)); // white-hot core
            shell(buf, m, radius * 0.85f, 1.00f, 0.88f, 0.22f, a(0.45f * op));           // golden middle
            shell(buf, m, shellR,         1.00f, 0.78f, 0.10f, a(0.60f * op));           // yellow shell

            // Lightning goes on last, outside the shell. It is white-hot with a yellow glow so it
            // stays visible against the (already yellow) ball.
            float ox = (float) dx, oy = (float) dy, oz = (float) dz;
            if (ShiftBallConfig.arcs && ShiftBallConfig.arcCount > 0) {
                radialArcs(buf, m, b, age, shellR, ox, oy, oz);
            }
            if (ShiftBallConfig.surfaceArcs > 0) {
                surfaceArcs(buf, m, b, age, shellR, ox, oy, oz);
            }
            if (ShiftBallConfig.sparks && ShiftBallConfig.sparkCount > 0) {
                sparks(buf, m, b, age, shellR, ox, oy, oz);
            }
            matrices.pop();
            drewAnything = true;
        }

        if (drewAnything && consumers instanceof VertexConsumerProvider.Immediate immediate) {
            immediate.draw(RenderLayer.getLightning());
        }
    }

    private static float a(float alpha) {
        return Math.min(1f, Math.max(0f, alpha));
    }

    /** Emits a sphere shell with both windings so it is visible from inside (the shifter's own view). */
    private static void shell(VertexConsumer buf, Matrix4f m, float r, float cr, float cg, float cb, float ca) {
        float[] q = MESH.quads;
        for (int i = 0; i < MESH.quadCount; i++) {
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                vertex(buf, m, q[o + k * 3] * r, q[o + k * 3 + 1] * r, q[o + k * 3 + 2] * r, cr, cg, cb, ca);
            }
            for (int k = 3; k >= 0; k--) {
                vertex(buf, m, q[o + k * 3] * r, q[o + k * 3 + 1] * r, q[o + k * 3 + 2] * r, cr, cg, cb, ca);
            }
        }
    }

    /** Long jagged bolts shooting out of the ball, some with a fork. Re-rolled every ~1.5 ticks to flicker. */
    private static void radialArcs(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float shellR,
                                   float ox, float oy, float oz) {
        long step = (long) (age / 1.5f);
        float glow = Math.max(0.06f, shellR * 0.016f * ShiftBallConfig.arcWidth);
        float core = Math.max(0.025f, shellR * 0.006f * ShiftBallConfig.arcWidth);

        for (int i = 0; i < ShiftBallConfig.arcCount; i++) {
            long seed = b.seed * 31L + i * 7919L + step * 104729L;
            Random gate = new Random(seed ^ 0x5DEECE66DL);
            if (gate.nextFloat() < 0.2f) continue; // random dropouts so it crackles
            float length = shellR * ShiftBallConfig.arcReach * (0.5f + 0.7f * gate.nextFloat());
            float[] pts = LightningArcs.arc(seed, shellR, length, ARC_SEGMENTS);
            polyline(buf, m, pts, ox, oy, oz, glow, core);
            if (gate.nextFloat() < 0.6f) {
                int idx = 2 + gate.nextInt(3);
                float[] fork = LightningArcs.branch(seed + 1L, pts, idx, length * 0.45f, 4);
                polyline(buf, m, fork, ox, oy, oz, glow * 0.7f, core * 0.7f);
            }
        }
    }

    /** Lightning crawling over the surface of the ball, like the crackling skin in the anime. */
    private static void surfaceArcs(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float shellR,
                                    float ox, float oy, float oz) {
        long step = (long) (age / 1.5f);
        float glow = Math.max(0.05f, shellR * 0.013f * ShiftBallConfig.arcWidth);
        float core = Math.max(0.02f, shellR * 0.005f * ShiftBallConfig.arcWidth);

        for (int i = 0; i < ShiftBallConfig.surfaceArcs; i++) {
            long seed = b.seed * 37L + i * 6151L + step * 130363L;
            if (new Random(seed ^ 0x2545F4914F6CDD1DL).nextFloat() < 0.15f) continue;
            float[] pts = LightningArcs.surfaceArc(seed, shellR * 1.015f, SURFACE_SEGMENTS);
            polyline(buf, m, pts, ox, oy, oz, glow, core);
        }
    }

    /** Small sparks that fly off the ball and fade out; each loops through its own short life. */
    private static void sparks(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float shellR,
                               float ox, float oy, float oz) {
        float half = Math.max(0.04f, shellR * 0.0045f * ShiftBallConfig.arcWidth);
        for (int i = 0; i < ShiftBallConfig.sparkCount; i++) {
            Random r = new Random(b.seed * 17L + i * 104729L);
            float life = 8f + 10f * r.nextFloat();      // ticks
            float x = age + r.nextFloat() * life;
            long cycle = (long) (x / life);
            float t = (x - cycle * life) / life;
            float[] sp = LightningArcs.spark(b.seed * 131L + i * 7727L + cycle * 104729L, shellR, t);
            float alpha = a(0.95f * (1f - t));
            strip(buf, m, sp[0], sp[1], sp[2], sp[3], sp[4], sp[5], ox, oy, oz, half,
                    1.00f, 0.96f, 0.65f, alpha);
        }
    }

    /** Draws a polyline twice: a wide yellow glow and a thin white-hot core. */
    private static void polyline(VertexConsumer buf, Matrix4f m, float[] pts, float ox, float oy, float oz,
                                 float glowHalf, float coreHalf) {
        int segs = pts.length / 3 - 1;
        for (int k = 0; k < segs; k++) {
            float px = pts[k * 3], py = pts[k * 3 + 1], pz = pts[k * 3 + 2];
            float qx = pts[k * 3 + 3], qy = pts[k * 3 + 4], qz = pts[k * 3 + 5];
            strip(buf, m, px, py, pz, qx, qy, qz, ox, oy, oz, glowHalf, 1.00f, 0.88f, 0.25f, 0.45f);
            strip(buf, m, px, py, pz, qx, qy, qz, ox, oy, oz, coreHalf, 1.00f, 1.00f, 0.90f, 1.00f);
        }
    }

    /** A camera-facing quad strip between two points (ball-local); o* is the ball offset from the camera. */
    private static void strip(VertexConsumer buf, Matrix4f m,
                              float px, float py, float pz, float qx, float qy, float qz,
                              float ox, float oy, float oz, float half,
                              float cr, float cg, float cb, float ca) {
        float dx = qx - px, dy = qy - py, dz = qz - pz;
        // View vector from the camera (origin) to the segment midpoint.
        float vx = ox + (px + qx) * 0.5f, vy = oy + (py + qy) * 0.5f, vz = oz + (pz + qz) * 0.5f;
        float sx = dy * vz - dz * vy;
        float sy = dz * vx - dx * vz;
        float sz = dx * vy - dy * vx;
        float len = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (len < 1e-6f) return;
        float k = half / len;
        sx *= k;
        sy *= k;
        sz *= k;
        vertex(buf, m, px - sx, py - sy, pz - sz, cr, cg, cb, ca);
        vertex(buf, m, px + sx, py + sy, pz + sz, cr, cg, cb, ca);
        vertex(buf, m, qx + sx, qy + sy, qz + sz, cr, cg, cb, ca);
        vertex(buf, m, qx - sx, qy - sy, qz - sz, cr, cg, cb, ca);
    }

    private static void vertex(VertexConsumer buf, Matrix4f m, float x, float y, float z,
                               float r, float g, float bl, float a) {
        buf.vertex(m, x, y, z).color(r, g, bl, a);
    }
}
