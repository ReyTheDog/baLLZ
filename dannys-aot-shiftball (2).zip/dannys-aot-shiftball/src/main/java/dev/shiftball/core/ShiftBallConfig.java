package dev.shiftball.core;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/** Simple properties-file config. Missing keys fall back to defaults and are written back. */
public final class ShiftBallConfig {
    private ShiftBallConfig() {}

    /** Bumped when defaults change; an older file is replaced by the new defaults once. */
    public static final int CONFIG_VERSION = 2;

    /** Master switch for the whole addon. */
    public static boolean enabled = true;
    /** Suppress the original AAA-Particles "shift" cloud and show the ball instead. */
    public static boolean replaceCloud = true;
    /** Also show the ball for the Colossal Titan (it keeps its own nuke effect either way). */
    public static boolean includeColossal = false;
    /** Also show the ball when a villager turns into a pure titan. */
    public static boolean includePureTitans = true;
    /** How long the ball lasts for pure titans, in ticks (20 = 1 second). */
    public static float pureTitanDuration = 40f;

    /** Lightning bolts that shoot out of the ball (with forks). */
    public static boolean arcs = true;
    public static int arcCount = 10;
    /** Multiplier for lightning thickness. */
    public static float arcWidth = 1.5f;
    /** Length of the outward bolts as a fraction of the ball radius. */
    public static float arcReach = 0.8f;
    /** Lightning that crawls over the surface of the ball. */
    public static int surfaceArcs = 6;
    /** Little sparks that fly off the ball. */
    public static boolean sparks = true;
    public static int sparkCount = 40;

    /**
     * The ball never gets smaller than half the titan's (widened) hitbox diagonal * coverage (the
     * smallest sphere that contains the whole hitbox), so it always covers the titan. 1.1 leaves a
     * margin for arms and models that stick out of the hitbox.
     */
    public static float coverage = 1.1f;
    /**
     * Small titans (under ~6 blocks tall, e.g. Cart and Jaw) are low and wide inside thin hitboxes.
     * Their hitbox is widened by this fraction of their height on each side before the ball is sized.
     */
    public static float smallReach = 0.45f;
    /** Extra manual size multiplier if a titan still sticks out (or the ball is too big). */
    public static float sizeMultiplier = 1.0f;
    /** Brightness/opaqueness of the ball. Raise towards 1.5 to hide the titan more strongly. */
    public static float opacity = 1.0f;
    /**
     * Smallest pulse size relative to the largest. The pulse's smallest size is the covering
     * radius, so a LOWER value means the ball gets BIGGER at its peak (more dramatic pulse);
     * 0.75 means it swells to about 1.37x the covering size.
     */
    public static float minPulse = 0.75f;
    /** Pulses per second at the start (speeds up towards the end). */
    public static float pulseHz = 1.6f;
    /** Do not draw the ball beyond this distance (blocks). */
    public static float maxDistance = 512f;
    /** Covering radius used if the titan entity cannot be found on the client (about a 15-block titan). */
    public static float fallbackRadius = 8.5f;
    /** Log ball sizes and titan ids to the console. */
    public static boolean debug = false;

    /** Exact covering radius per titan, by entity id path, e.g. cart_shifter_titan -> 5.0. */
    public static final Map<String, Float> coverOverrides = new HashMap<>();

    private static final String OVERRIDE_PREFIX = "coverRadius.";

    public static void load(Path file) {
        Properties p = new Properties();
        if (Files.isRegularFile(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                p.load(r);
            } catch (IOException ignored) {
                // fall back to defaults
            }
        }
        // A file from an older version is replaced by the new defaults once.
        if (Math.round(num(p, "configVersion", 1)) < CONFIG_VERSION) {
            p.clear();
        }

        enabled = bool(p, "enabled", enabled);
        replaceCloud = bool(p, "replaceCloud", replaceCloud);
        includeColossal = bool(p, "includeColossal", includeColossal);
        includePureTitans = bool(p, "includePureTitans", includePureTitans);
        pureTitanDuration = clamp(num(p, "pureTitanDuration", pureTitanDuration), 10f, 200f);
        arcs = bool(p, "arcs", arcs);
        arcCount = Math.round(clamp(num(p, "arcCount", arcCount), 0f, 30f));
        arcWidth = clamp(num(p, "arcWidth", arcWidth), 0.1f, 6f);
        arcReach = clamp(num(p, "arcReach", arcReach), 0.1f, 3f);
        surfaceArcs = Math.round(clamp(num(p, "surfaceArcs", surfaceArcs), 0f, 30f));
        sparks = bool(p, "sparks", sparks);
        sparkCount = Math.round(clamp(num(p, "sparkCount", sparkCount), 0f, 200f));
        coverage = clamp(num(p, "coverage", coverage), 0.3f, 3f);
        smallReach = clamp(num(p, "smallReach", smallReach), 0f, 2f);
        sizeMultiplier = clamp(num(p, "sizeMultiplier", sizeMultiplier), 0.1f, 10f);
        opacity = clamp(num(p, "opacity", opacity), 0.2f, 3f);
        minPulse = clamp(num(p, "minPulse", minPulse), 0.1f, 1f);
        pulseHz = clamp(num(p, "pulseHz", pulseHz), 0.2f, 6f);
        maxDistance = clamp(num(p, "maxDistance", maxDistance), 16f, 4096f);
        fallbackRadius = clamp(num(p, "fallbackRadius", fallbackRadius), 0.5f, 100f);
        debug = bool(p, "debug", debug);

        coverOverrides.clear();
        for (String key : p.stringPropertyNames()) {
            if (!key.startsWith(OVERRIDE_PREFIX)) continue;
            try {
                float v = Float.parseFloat(p.getProperty(key).trim());
                if (v > 0f) {
                    coverOverrides.put(key.substring(OVERRIDE_PREFIX.length()).trim().toLowerCase(Locale.ROOT),
                            clamp(v, 0.5f, 200f));
                }
            } catch (NumberFormatException ignored) {
                // skip garbage
            }
        }
        write(file);
    }

    private static void write(Path file) {
        StringBuilder s = new StringBuilder();
        s.append("# Danny's AoT - Titan Shift Ball config\n");
        s.append("configVersion=").append(CONFIG_VERSION).append("\n");
        s.append("enabled=").append(enabled).append("\n");
        s.append("# Hide the original (laggy) shift cloud and show the ball instead\n");
        s.append("replaceCloud=").append(replaceCloud).append("\n");
        s.append("# Also show the ball for the Colossal Titan\n");
        s.append("includeColossal=").append(includeColossal).append("\n");
        s.append("# Also show the ball when a villager turns into a pure titan, and how long it lasts (ticks)\n");
        s.append("includePureTitans=").append(includePureTitans).append("\n");
        s.append("pureTitanDuration=").append(pureTitanDuration).append("\n");
        s.append("# Lightning bolts shooting out of the ball (with forks), their thickness and length\n");
        s.append("arcs=").append(arcs).append("\n");
        s.append("arcCount=").append(arcCount).append("\n");
        s.append("arcWidth=").append(arcWidth).append("\n");
        s.append("arcReach=").append(arcReach).append("\n");
        s.append("# Lightning crawling over the surface of the ball\n");
        s.append("surfaceArcs=").append(surfaceArcs).append("\n");
        s.append("# Little sparks flying off the ball\n");
        s.append("sparks=").append(sparks).append("\n");
        s.append("sparkCount=").append(sparkCount).append("\n");
        s.append("# The ball never gets smaller than half the titan hitbox diagonal * coverage * sizeMultiplier\n");
        s.append("# (the smallest sphere that contains the whole titan). Raise them if anything sticks out.\n");
        s.append("coverage=").append(coverage).append("\n");
        s.append("# Small titans (Cart, Jaw, small pure titans) are low and wide inside thin hitboxes: their\n");
        s.append("# hitbox is widened by this fraction of their height per side. Raise if their body still shows.\n");
        s.append("smallReach=").append(smallReach).append("\n");
        s.append("sizeMultiplier=").append(sizeMultiplier).append("\n");
        s.append("# Brightness of the ball (raise to hide the titan more strongly)\n");
        s.append("opacity=").append(opacity).append("\n");
        s.append("# Smallest pulse as a fraction of the largest. The smallest pulse = covering size, so\n");
        s.append("# a lower value makes the ball swell bigger at its peak\n");
        s.append("minPulse=").append(minPulse).append("\n");
        s.append("# Pulses per second at the start (speeds up towards the end)\n");
        s.append("pulseHz=").append(pulseHz).append("\n");
        s.append("maxDistance=").append(maxDistance).append("\n");
        s.append("fallbackRadius=").append(fallbackRadius).append("\n");
        s.append("# Logs each titan's id, hitbox and ball size to the console\n");
        s.append("debug=").append(debug).append("\n");
        s.append("# Exact covering radius for one titan (entity id without the namespace), overrides the formula.\n");
        s.append("# Examples:  coverRadius.cart_shifter_titan=5.0   coverRadius.test_shifter_titan=5.5 (Jaw)\n");
        for (Map.Entry<String, Float> e : coverOverrides.entrySet()) {
            s.append(OVERRIDE_PREFIX).append(e.getKey()).append("=").append(e.getValue()).append("\n");
        }
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, s.toString());
        } catch (IOException ignored) {
            // read-only config dir is fine
        }
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    private static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
