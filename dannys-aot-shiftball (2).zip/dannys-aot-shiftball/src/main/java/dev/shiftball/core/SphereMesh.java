package dev.shiftball.core;

/** A unit UV-sphere stored as quads (12 floats per quad: 4 vertices x xyz). */
public final class SphereMesh {
    public final float[] quads;
    public final int quadCount;

    public SphereMesh(int segments, int rings) {
        this.quadCount = segments * rings;
        this.quads = new float[quadCount * 12];
        int o = 0;
        for (int i = 0; i < rings; i++) {
            for (int j = 0; j < segments; j++) {
                o = put(o, i, j, segments, rings);
                o = put(o, i + 1, j, segments, rings);
                o = put(o, i + 1, j + 1, segments, rings);
                o = put(o, i, j + 1, segments, rings);
            }
        }
    }

    private int put(int o, int ring, int seg, int segments, int rings) {
        double theta = Math.PI * ring / rings;
        double phi = 2.0 * Math.PI * seg / segments;
        double r = Math.sin(theta);
        quads[o] = (float) (r * Math.cos(phi));
        quads[o + 1] = (float) Math.cos(theta);
        quads[o + 2] = (float) (r * Math.sin(phi));
        return o + 3;
    }
}
