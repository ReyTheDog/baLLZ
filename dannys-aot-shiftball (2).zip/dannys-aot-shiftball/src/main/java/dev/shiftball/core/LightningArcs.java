package dev.shiftball.core;

import java.util.Random;

/**
 * Generates the lightning geometry around the ball. Pure Java; every function is deterministic
 * for a given seed so the renderer can re-roll the bolts every couple of ticks (flicker) without
 * keeping any state.
 */
public final class LightningArcs {
    private LightningArcs() {}

    private static double[] randomUnit(Random rnd) {
        double x, y, z, len;
        do {
            x = rnd.nextGaussian();
            y = rnd.nextGaussian();
            z = rnd.nextGaussian();
            len = Math.sqrt(x * x + y * y + z * z);
        } while (len < 1e-6);
        return new double[] {x / len, y / len, z / len};
    }

    /**
     * A jagged bolt that starts exactly on the sphere of {@code startRadius} and runs outward.
     *
     * @return (segments + 1) points as flat xyz, relative to the ball centre
     */
    public static float[] arc(long seed, float startRadius, float length, int segments) {
        Random rnd = new Random(seed);
        double[] u = randomUnit(rnd);
        float jitter = length * 0.16f;
        float[] pts = new float[(segments + 1) * 3];
        for (int k = 0; k <= segments; k++) {
            float t = k / (float) segments;
            float d = startRadius + length * t;
            float jx = (rnd.nextFloat() - 0.5f) * 2f * jitter;
            float jy = (rnd.nextFloat() - 0.5f) * 2f * jitter;
            float jz = (rnd.nextFloat() - 0.5f) * 2f * jitter;
            if (k == 0) {
                jx = 0f;
                jy = 0f;
                jz = 0f;
            }
            pts[k * 3] = (float) u[0] * d + jx;
            pts[k * 3 + 1] = (float) u[1] * d + jy;
            pts[k * 3 + 2] = (float) u[2] * d + jz;
        }
        return pts;
    }

    /**
     * A short fork that leaves point {@code index} of {@code arc} (it starts exactly on that point),
     * heading roughly outward but veering off to the side.
     */
    public static float[] branch(long seed, float[] arc, int index, float length, int segments) {
        Random rnd = new Random(seed);
        float sx = arc[index * 3], sy = arc[index * 3 + 1], sz = arc[index * 3 + 2];
        double len = Math.sqrt(sx * sx + sy * sy + sz * sz);
        double[] out = len > 1e-6 ? new double[] {sx / len, sy / len, sz / len} : randomUnit(rnd);
        double[] r = randomUnit(rnd);
        double dx = out[0] + 1.1 * r[0], dy = out[1] + 1.1 * r[1], dz = out[2] + 1.1 * r[2];
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= dl;
        dy /= dl;
        dz /= dl;
        float jitter = length * 0.18f;
        float[] pts = new float[(segments + 1) * 3];
        pts[0] = sx;
        pts[1] = sy;
        pts[2] = sz;
        for (int k = 1; k <= segments; k++) {
            float t = k / (float) segments;
            pts[k * 3] = sx + (float) dx * length * t + (rnd.nextFloat() - 0.5f) * 2f * jitter;
            pts[k * 3 + 1] = sy + (float) dy * length * t + (rnd.nextFloat() - 0.5f) * 2f * jitter;
            pts[k * 3 + 2] = sz + (float) dz * length * t + (rnd.nextFloat() - 0.5f) * 2f * jitter;
        }
        return pts;
    }

    /**
     * Lightning that crawls over the surface of the ball: a kinked path that stays on the sphere of
     * {@code radius}, like the crackling skin of the ball in the anime.
     */
    public static float[] surfaceArc(long seed, float radius, int segments) {
        Random rnd = new Random(seed);
        double[] u = randomUnit(rnd);
        double[] t = randomUnit(rnd);
        orthogonalize(t, u);
        float[] pts = new float[(segments + 1) * 3];
        for (int k = 0; k <= segments; k++) {
            pts[k * 3] = (float) (u[0] * radius);
            pts[k * 3 + 1] = (float) (u[1] * radius);
            pts[k * 3 + 2] = (float) (u[2] * radius);
            if (k == segments) break;
            double a = 0.10 + 0.10 * rnd.nextDouble();
            double c = Math.cos(a), s = Math.sin(a);
            double[] nu = {u[0] * c + t[0] * s, u[1] * c + t[1] * s, u[2] * c + t[2] * s};
            double[] nt = {-u[0] * s + t[0] * c, -u[1] * s + t[1] * c, -u[2] * s + t[2] * c};
            u = nu;
            t = nt;
            double[] r = randomUnit(rnd);
            t[0] += 0.9 * r[0];
            t[1] += 0.9 * r[1];
            t[2] += 0.9 * r[2];
            orthogonalize(t, u);
        }
        return pts;
    }

    /** Makes t perpendicular to u (u is unit length) and normalises t, in place. */
    private static void orthogonalize(double[] t, double[] u) {
        double dot = t[0] * u[0] + t[1] * u[1] + t[2] * u[2];
        t[0] -= u[0] * dot;
        t[1] -= u[1] * dot;
        t[2] -= u[2] * dot;
        double l = Math.sqrt(t[0] * t[0] + t[1] * t[1] + t[2] * t[2]);
        if (l < 1e-9) { // degenerate: pick any perpendicular
            t[0] = -u[1];
            t[1] = u[0];
            t[2] = 0;
            l = Math.sqrt(t[0] * t[0] + t[1] * t[1]);
            if (l < 1e-9) {
                t[0] = 1;
                t[1] = 0;
                t[2] = 0;
                l = 1;
            }
        }
        t[0] /= l;
        t[1] /= l;
        t[2] /= l;
    }

    /**
     * One spark flying off the ball. {@code t} runs 0..1 over its life.
     *
     * @return {headX, headY, headZ, tailX, tailY, tailZ}: a short streak pointing along its flight
     */
    public static float[] spark(long seed, float radius, float t) {
        Random rnd = new Random(seed);
        double[] u = randomUnit(rnd);
        float head = radius * (1.0f + 0.85f * t);
        float tail = Math.max(radius, head - radius * 0.14f * (1f - 0.4f * t));
        return new float[] {
                (float) u[0] * head, (float) u[1] * head, (float) u[2] * head,
                (float) u[0] * tail, (float) u[1] * tail, (float) u[2] * tail};
    }
}
