package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels the mod's AAA-Particles "shift" cloud, but only while TitanShiftSoundHandler#onTitanSpawn
 * is running (the shifter path). The villager-transformation path calls the same helper outside of
 * that window and is therefore untouched.
 *
 * "spawnShiftParticle" matches both overloads, (World,D,D,D) and (World,D,D,D,F); no descriptor is
 * written so there are no Minecraft types to remap.
 */
@Pseudo
@Mixin(targets = "daot.ShiftParticleHelper")
public abstract class ShiftParticleHelperMixin {

    @Inject(method = "spawnShiftParticle", at = @At("HEAD"), cancellable = true, remap = false)
    private static void shiftball$suppressCloud(CallbackInfo ci) {
        if (ShiftBallManager.shouldSuppressCloud()) {
            ci.cancel();
        }
    }
}
