package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks daot.TitanShiftSoundHandler#onTitanSpawn(double x, double y, double z, int titanEntityId, int titanType),
 * the client handler for the mod's TitanSpawnPayload. It is where the mod starts the shift cloud.
 * The class is targeted by name, so this addon needs no compile-time dependency on the mod.
 */
@Pseudo
@Mixin(targets = "daot.TitanShiftSoundHandler")
public abstract class TitanShiftSoundHandlerMixin {

    @Inject(method = "onTitanSpawn", at = @At("HEAD"), remap = false)
    private static void shiftball$begin(double x, double y, double z, int titanEntityId, int titanType,
                                        CallbackInfo ci) {
        ShiftBallManager.onTitanSpawn(x, y, z, titanEntityId, titanType);
    }

    @Inject(method = "onTitanSpawn", at = @At("RETURN"), remap = false)
    private static void shiftball$end(double x, double y, double z, int titanEntityId, int titanType,
                                      CallbackInfo ci) {
        ShiftBallManager.endTitanSpawn();
    }
}
