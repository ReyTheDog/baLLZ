package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.render.entity.LivingEntityRenderer;

/**
 * Makes the body of a charging-up shifter (or villager) actually glow yellow: while its model is drawn
 * the colour is multiplied towards golden yellow and the light is pulled towards full brightness.
 * Everything is {@code require = 0}: if a future Minecraft changes these methods the glow simply does
 * not appear, the game still starts.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    private static final String RENDER =
            "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;I)V";
    // The call is "this.model.render(...)". The owner in the bytecode is the type of the field
    // (EntityModel) or the class that declares the method (Model); both are listed, only one matches.
    private static final String MODEL_RENDER_A =
            "Lnet/minecraft/client/render/entity/model/EntityModel;"
                    + "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V";
    private static final String MODEL_RENDER_B =
            "Lnet/minecraft/client/model/Model;"
                    + "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V";

    @Inject(method = RENDER, at = @At("HEAD"), require = 0)
    private void shiftball$begin(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                 VertexConsumerProvider consumers, int light, CallbackInfo ci) {
        ShiftBallManager.beginRender(entity.getId());
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void shiftball$end(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                               VertexConsumerProvider consumers, int light, CallbackInfo ci) {
        ShiftBallManager.endRender();
    }

    /** index 2 of render(matrices, vertices, light, overlay, color) is the light. */
    @ModifyArg(method = RENDER, at = @At(value = "INVOKE", target = MODEL_RENDER_A), index = 2, require = 0)
    private int shiftball$lightA(int light) {
        return ShiftBallManager.tintLight(light);
    }

    @ModifyArg(method = RENDER, at = @At(value = "INVOKE", target = MODEL_RENDER_B), index = 2, require = 0)
    private int shiftball$lightB(int light) {
        return ShiftBallManager.tintLight(light);
    }

    /** index 4 is the colour (ARGB multiplier). */
    @ModifyArg(method = RENDER, at = @At(value = "INVOKE", target = MODEL_RENDER_A), index = 4, require = 0)
    private int shiftball$colorA(int color) {
        return ShiftBallManager.tintColor(color);
    }

    @ModifyArg(method = RENDER, at = @At(value = "INVOKE", target = MODEL_RENDER_B), index = 4, require = 0)
    private int shiftball$colorB(int color) {
        return ShiftBallManager.tintColor(color);
    }
}
