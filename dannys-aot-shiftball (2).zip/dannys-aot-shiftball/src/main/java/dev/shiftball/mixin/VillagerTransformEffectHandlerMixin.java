package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks daot.VillagerTransformEffectHandler#onTitanSpawnFromVillager(double x, double y, double z,
 * int titanEntityId), the client handler for VillagerTransformSpawnPayload: the moment a villager
 * turns into a pure titan. The mod spawns a small shift cloud there; we replace it with the ball.
 */
@Pseudo
@Mixin(targets = "daot.VillagerTransformEffectHandler")
public abstract class VillagerTransformEffectHandlerMixin {

    @Inject(method = "onTitanSpawnFromVillager", at = @At("HEAD"), remap = false)
    private static void shiftball$begin(double x, double y, double z, int titanEntityId, CallbackInfo ci) {
        ShiftBallManager.onPureTitanSpawn(x, y, z, titanEntityId);
    }

    @Inject(method = "onTitanSpawnFromVillager", at = @At("RETURN"), remap = false)
    private static void shiftball$end(double x, double y, double z, int titanEntityId, CallbackInfo ci) {
        ShiftBallManager.endTitanSpawn();
    }
}
