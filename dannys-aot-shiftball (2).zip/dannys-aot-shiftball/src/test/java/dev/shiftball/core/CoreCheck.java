package dev.shiftball.core;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Dependency-free checks for the pure logic. Run: java dev.shiftball.core.CoreCheck */
public final class CoreCheck {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        if (!ok) failures++;
    }

    private static double len(float[] a, int i) {
        return Math.sqrt(a[i * 3] * a[i * 3] + a[i * 3 + 1] * a[i * 3 + 1] + a[i * 3 + 2] * a[i * 3 + 2]);
    }

    public static void main(String[] args) throws Exception {
        // ---- Config (first, while the static fields still hold their defaults) ----
        Path dir = Files.createTempDirectory("shiftball-check");
        Path old = dir.resolve("old.properties");
        Files.writeString(old, "arcCount=6\narcWidth=1.0\nminPulse=0.65\ncoverRadius.cart_shifter_titan=9\n");
        ShiftBallConfig.load(old);
        check(ShiftBallConfig.arcCount == 10 && ShiftBallConfig.arcWidth == 1.5f && ShiftBallConfig.minPulse == 0.75f,
                "an old-version config is replaced by the new defaults once");
        check(ShiftBallConfig.coverOverrides.isEmpty(), "old-version overrides are dropped with it");
        check(Files.readString(old).contains("configVersion=" + ShiftBallConfig.CONFIG_VERSION), "config is rewritten with the current version");

        Path cur = dir.resolve("cur.properties");
        Files.writeString(cur, "configVersion=2\nminPulse=5\npulseHz=abc\narcCount=3\nenabled=false\n"
                + "coverRadius.Cart_Shifter_Titan=5.5\ncoverRadius.bad=xyz\n");
        ShiftBallConfig.load(cur);
        check(ShiftBallConfig.minPulse == 1f, "config clamps out-of-range values");
        check(ShiftBallConfig.pulseHz == 1.6f, "config falls back to default on garbage");
        check(ShiftBallConfig.arcCount == 3 && !ShiftBallConfig.enabled, "config reads valid values");
        check(ShiftBallConfig.coverOverrides.size() == 1 && ShiftBallConfig.coverOverrides.get("cart_shifter_titan") == 5.5f,
                "per-titan cover override is read (id lower-cased, garbage skipped)");
        check(Files.readString(cur).contains("coverRadius.cart_shifter_titan=5.5") && Files.readString(cur).contains("sparkCount="),
                "config writes overrides and missing keys back");
        ShiftBallConfig.enabled = true;
        ShiftBallConfig.minPulse = 0.75f;

        // ---- Pulse shape ----
        for (float duration : new float[] {80f, 95f, 40f}) {
            check(BallMath.scale(0f, duration, 0.65f, 1.6f) == 0f, "scale is 0 at start (D=" + duration + ")");
            check(BallMath.scale(duration, duration, 0.65f, 1.6f) == 0f, "scale is 0 at end (D=" + duration + ")");
            float max = 0f;
            boolean nonNegative = true;
            for (float a = 0.25f; a < duration; a += 0.25f) {
                float s = BallMath.scale(a, duration, 0.65f, 1.6f);
                max = Math.max(max, s);
                if (s < 0f) nonNegative = false;
            }
            check(nonNegative, "scale never negative (D=" + duration + ")");
            check(max <= 1.026f && max >= 0.95f, "ball reaches ~full size and not beyond (max=" + max + ", D=" + duration + ")");
        }
        int risings = 0;
        boolean high = false, started = false;
        for (float a = 0.1f * 80f; a < 0.88f * 80f; a += 0.1f) {
            float s = BallMath.scale(a, 80f, 0.6f, 1.6f);
            if (s > 0.84f && !high) { if (started) risings++; high = true; started = true; }
            if (s < 0.76f) high = false;
        }
        check(risings >= 3, "it keeps shrinking and growing: at least 4 pulses in a normal shift (risings=" + risings + ")");

        // ---- Mesh ----
        SphereMesh mesh = new SphereMesh(18, 12);
        check(mesh.quadCount == 216 && mesh.quads.length == 216 * 12, "sphere mesh has 216 quads");
        boolean unit = true;
        for (int i = 0; i < mesh.quads.length / 3; i++) if (Math.abs(len(mesh.quads, i) - 1.0) > 1e-5) unit = false;
        check(unit, "every sphere vertex lies on the unit sphere");

        double inradius = Double.MAX_VALUE;
        float[] cq = mesh.quads;
        for (int i = 0; i < mesh.quadCount; i++) {
            int o = i * 12;
            double d1x = cq[o + 6] - cq[o], d1y = cq[o + 7] - cq[o + 1], d1z = cq[o + 8] - cq[o + 2];
            double d2x = cq[o + 9] - cq[o + 3], d2y = cq[o + 10] - cq[o + 4], d2z = cq[o + 11] - cq[o + 5];
            double nx = d1y * d2z - d1z * d2y, ny = d1z * d2x - d1x * d2z, nz = d1x * d2y - d1y * d2x;
            double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1e-9) continue;
            inradius = Math.min(inradius, Math.abs((nx * cq[o] + ny * cq[o + 1] + nz * cq[o + 2]) / nl));
        }
        check(inradius * BallMath.TESSELLATION >= 1.0, "outer shell scaled by TESSELLATION never dips inside the covering radius (inradius=" + inradius + ")");

        // ---- Coverage of every titan hitbox (width, height) in Danny's AoT 2.5.2 ----
        // shifters: attack/armored, female, ogre, test (= Jaw), cart, colossal; pure: small/medium sizes
        double[][] hitboxes = {{2.3, 15}, {2.1, 14}, {1.7, 10}, {0.8, 5.5}, {1.6, 4.0}, {9.3, 60}, {0.7, 4}, {1.0, 6}, {1.5, 8}, {2.0, 12}};
        float cov = ShiftBallConfig.coverage, reach = ShiftBallConfig.smallReach;
        for (double[] hb : hitboxes) {
            double w = hb[0], h = hb[1];
            for (float minPulse : new float[] {0.75f, 0.5f}) {
                for (float duration : new float[] {80f, 95f, 40f}) {
                    float cover = BallMath.coverRadius(w, h, w, cov, 1.0f, reach);
                    float full = BallMath.fullRadius(cover, minPulse);
                    double needed = BallMath.inflatedHalfDiagonal(w, h, w, reach); // far corner of the widened hitbox
                    double lowest = Double.MAX_VALUE;
                    for (float a = 0.09f * duration; a <= duration * 0.88f; a += 0.1f) {
                        double r = full * BallMath.scale(a, duration, minPulse, 1.6f) * BallMath.TESSELLATION * inradius;
                        lowest = Math.min(lowest, r);
                    }
                    check(lowest >= needed, String.format("%.1fx%.1f titan (minPulse %.2f, D=%.0f) covered from 9%%..88%%: shell inner edge %.2f >= far corner %.2f",
                            w, h, minPulse, duration, lowest, needed));
                }
            }
        }
        double cartOld = 0.5 * Math.sqrt(1.6 * 1.6 * 2 + 16) * 1.1;
        double jawOld = 0.5 * Math.sqrt(0.8 * 0.8 * 2 + 5.5 * 5.5) * 1.1;
        float cartNew = BallMath.coverRadius(1.6, 4.0, 1.6, cov, 1f, reach);
        float jawNew = BallMath.coverRadius(0.8, 5.5, 0.8, cov, 1f, reach);
        check(cartNew > cartOld * 1.5, String.format("Cart titan ball is now much bigger (%.2f -> %.2f blocks)", cartOld, cartNew));
        check(jawNew > jawOld * 1.4, String.format("Jaw titan ball is now much bigger (%.2f -> %.2f blocks)", jawOld, jawNew));
        check(BallMath.coverRadius(2.3, 15, 2.3, cov, 1f, reach) == (float) (0.5 * Math.sqrt(2.3 * 2.3 * 2 + 225) * cov),
                "tall titans (Attack/Armored 15 blocks) keep exactly the size you said was nearly perfect");
        check(BallMath.coverRadius(2.1, 14, 2.1, cov, 1f, reach) == (float) (0.5 * Math.sqrt(2.1 * 2.1 * 2 + 196) * cov),
                "Female titan size unchanged");

        // ---- Lightning ----
        float[] arc = LightningArcs.arc(12345L, 8f, 6f, 7);
        check(arc.length == 8 * 3, "arc has segments+1 points");
        check(Math.abs(len(arc, 0) - 8f) < 1e-4, "arc starts exactly on the ball surface (r0=" + len(arc, 0) + ")");
        check(len(arc, 7) > 8f + 2f, "arc ends well outside the ball (r=" + len(arc, 7) + ")");
        check(Arrays.equals(arc, LightningArcs.arc(12345L, 8f, 6f, 7)), "arcs are deterministic per seed");
        check(!Arrays.equals(arc, LightningArcs.arc(12346L, 8f, 6f, 7)), "different seeds give different arcs");

        float[] fork = LightningArcs.branch(99L, arc, 3, 3f, 4);
        check(fork.length == 5 * 3 && fork[0] == arc[9] && fork[1] == arc[10] && fork[2] == arc[11], "fork starts exactly on its parent bolt");
        check(Arrays.equals(fork, LightningArcs.branch(99L, arc, 3, 3f, 4)), "forks are deterministic");

        boolean onSphere = true, moves = true;
        for (long s = 1; s <= 50; s++) {
            float[] sa = LightningArcs.surfaceArc(s, 9f, 9);
            for (int i = 0; i <= 9; i++) if (Math.abs(len(sa, i) - 9f) > 1e-3) onSphere = false;
            for (int i = 0; i < 9; i++) {
                double dx = sa[i * 3 + 3] - sa[i * 3], dy = sa[i * 3 + 4] - sa[i * 3 + 1], dz = sa[i * 3 + 5] - sa[i * 3 + 2];
                if (Math.sqrt(dx * dx + dy * dy + dz * dz) < 0.2) moves = false;
            }
        }
        check(onSphere, "surface lightning stays on the ball surface (50 random bolts)");
        check(moves, "surface lightning advances at every step");

        boolean sparkOk = true;
        for (float t = 0f; t <= 1.0001f; t += 0.1f) {
            float[] sp = LightningArcs.spark(777L, 9f, t);
            double head = Math.sqrt(sp[0] * sp[0] + sp[1] * sp[1] + sp[2] * sp[2]);
            double tail = Math.sqrt(sp[3] * sp[3] + sp[4] * sp[4] + sp[5] * sp[5]);
            if (head < 9f - 1e-4 || tail < 9f - 1e-4 || tail > head + 1e-4) sparkOk = false;
        }
        check(sparkOk, "sparks start at the ball, fly outward, and the tail trails behind the head");

        System.out.println(failures == 0 ? "\nALL CHECKS PASSED" : "\n" + failures + " CHECK(S) FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
