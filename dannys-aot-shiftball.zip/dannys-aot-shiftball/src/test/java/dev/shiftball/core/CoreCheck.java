package dev.shiftball.core;

import java.nio.file.Files;
import java.nio.file.Path;

/** Dependency-free checks for the pure logic. Run: java dev.shiftball.core.CoreCheck */
public final class CoreCheck {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        if (!ok) failures++;
    }

    public static void main(String[] args) throws Exception {
        for (float duration : new float[] {80f, 95f}) {
            check(BallMath.scale(0f, duration, 0.65f, 1.6f) == 0f, "scale is 0 at start (D=" + duration + ")");
            check(BallMath.scale(duration, duration, 0.65f, 1.6f) == 0f, "scale is 0 at end (D=" + duration + ")");

            float min = Float.MAX_VALUE, max = 0f, plateauMin = Float.MAX_VALUE;
            boolean growing = true;
            float prevEnvelopeStart = 0f;
            for (float a = 0.25f; a < duration; a += 0.25f) {
                float s = BallMath.scale(a, duration, 0.65f, 1.6f);
                min = Math.min(min, s);
                max = Math.max(max, s);
                float p = a / duration;
                if (p >= 0.14f && p <= 0.86f) plateauMin = Math.min(plateauMin, s);
                if (s < 0f) growing = false;
            }
            check(growing, "scale never negative (D=" + duration + ")");
            check(max <= 1.026f, "scale never exceeds ~1.025 (max=" + max + ")");
            check(max >= 0.95f, "ball reaches ~full size (max=" + max + ")");
            check(plateauMin >= 0.65f * 0.97f - 0.001f, "mid-transformation never shrinks below minPulse (min=" + plateauMin + ")");
            check(plateauMin < 0.75f, "it really does shrink during the pulse (min=" + plateauMin + ")");
        }

        // Count how many times the radius shrinks-then-grows across the plateau (the "pulses").
        int turns = 0;
        float prev = BallMath.scale(10f, 80f, 0.65f, 1.6f), prevD = 0f;
        for (float a = 10.25f; a < 70f; a += 0.25f) {
            float s = BallMath.scale(a, 80f, 0.65f, 1.6f);
            float d = s - prev;
            if (prevD < 0 && d > 0) turns++;
            if (d != 0) prevD = d;
            prev = s;
        }
        check(turns >= 4, "at least 4 shrink-and-grow pulses in a normal shift (turns=" + turns + ")");

        // ---- Coverage: the ball must fully contain the titan hitbox at every moment of the pulse ----
        SphereMesh covMesh = new SphereMesh(18, 12);
        // Inradius of the faceted mesh = the smallest distance from the centre to any face plane.
        double inradius = Double.MAX_VALUE;
        float[] cq = covMesh.quads;
        for (int i = 0; i < covMesh.quadCount; i++) {
            int o = i * 12;
            double d1x = cq[o + 6] - cq[o], d1y = cq[o + 7] - cq[o + 1], d1z = cq[o + 8] - cq[o + 2];
            double d2x = cq[o + 9] - cq[o + 3], d2y = cq[o + 10] - cq[o + 4], d2z = cq[o + 11] - cq[o + 5];
            double nx = d1y * d2z - d1z * d2y, ny = d1z * d2x - d1x * d2z, nz = d1x * d2y - d1y * d2x;
            double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1e-9) continue;
            double dist = Math.abs((nx * cq[o] + ny * cq[o + 1] + nz * cq[o + 2]) / nl);
            inradius = Math.min(inradius, dist);
        }
        check(inradius * BallMath.TESSELLATION >= 1.0, "outer shell scaled by TESSELLATION never dips inside the covering radius (inradius=" + inradius + ")");

        // Real hitboxes from Danny's AoT 2.5.2 (width, height) of the shifter titans.
        double[][] hitboxes = {{2.3, 15}, {2.1, 14}, {1.7, 10}, {0.8, 5.5}, {1.6, 4.0}, {9.3, 60}};
        float[] coverages = {1.1f}; // the default
        for (double[] hb : hitboxes) {
            double w = hb[0], h = hb[1];
            for (float minPulse : new float[] {0.75f, 0.5f}) {
                for (float duration : new float[] {80f, 95f}) {
                    float cover = BallMath.coverRadius(w, h, w, coverages[0], 1.0f);
                    float full = BallMath.fullRadius(cover, minPulse);
                    double worstCorner = 0.5 * Math.sqrt(w * w + h * h + w * w); // box corner distance from centre
                    double lowest = Double.MAX_VALUE;
                    for (float a = 0.1f * duration * 0.8f; a <= duration * 0.88f; a += 0.1f) {
                        // inner edge of the outer shell's flat faces at this moment
                        double r = full * BallMath.scale(a, duration, minPulse, 1.6f) * BallMath.TESSELLATION * inradius;
                        lowest = Math.min(lowest, r);
                    }
                    check(lowest >= worstCorner, String.format("%.1fx%.0f titan (minPulse %.2f, D=%.0f) fully covered from 8%%..88%% of the shift: shell inner edge %.2f >= far corner %.2f",
                            w, h, minPulse, duration, lowest, worstCorner));
                }
            }
        }
        // And during the swell-in the ball is already at covering size by 8% of the shift (~6 ticks).
        float earlyCover = BallMath.coverRadius(2.3, 15, 2.3, 1.1f, 1.0f);
        float earlyFull = BallMath.fullRadius(earlyCover, 0.75f);
        check(earlyFull * BallMath.scale(0.09f * 80f, 80f, 0.75f, 1.6f) * BallMath.TESSELLATION * inradius >= 0.5 * Math.sqrt(2.3 * 2.3 * 2 + 225),
                "Attack/Armored titan already covered 9% into the shift (~7 ticks)");

        SphereMesh mesh = new SphereMesh(18, 12);
        check(mesh.quadCount == 216 && mesh.quads.length == 216 * 12, "sphere mesh has 216 quads");
        boolean unit = true;
        for (int i = 0; i < mesh.quads.length; i += 3) {
            double r = Math.sqrt(mesh.quads[i] * mesh.quads[i] + mesh.quads[i + 1] * mesh.quads[i + 1] + mesh.quads[i + 2] * mesh.quads[i + 2]);
            if (Math.abs(r - 1.0) > 1e-5) unit = false;
        }
        check(unit, "every sphere vertex lies on the unit sphere");

        float[] arc = LightningArcs.arc(12345L, 8f, 7);
        check(arc.length == 8 * 3, "arc has segments+1 points");
        double r0 = Math.sqrt(arc[0] * arc[0] + arc[1] * arc[1] + arc[2] * arc[2]);
        check(Math.abs(r0 - 8f * 0.92f) < 1e-4, "arc starts on the ball surface (r0=" + r0 + ")");
        double rEnd = Math.sqrt(arc[21] * arc[21] + arc[22] * arc[22] + arc[23] * arc[23]);
        check(rEnd > r0, "arc ends farther out than it starts");
        check(java.util.Arrays.equals(arc, LightningArcs.arc(12345L, 8f, 7)), "arcs are deterministic per seed");
        check(!java.util.Arrays.equals(arc, LightningArcs.arc(12346L, 8f, 7)), "different seeds give different arcs");

        Path tmp = Files.createTempDirectory("shiftball-check").resolve("cfg.properties");
        Files.writeString(tmp, "minPulse=5\npulseHz=abc\narcCount=3\nenabled=false\n");
        ShiftBallConfig.load(tmp);
        check(ShiftBallConfig.minPulse == 1f, "config clamps out-of-range values");
        check(ShiftBallConfig.pulseHz == 1.6f, "config falls back to default on garbage");
        check(ShiftBallConfig.arcCount == 3 && !ShiftBallConfig.enabled, "config reads valid values");
        check(Files.readString(tmp).contains("coverage="), "config writes missing keys back");

        System.out.println(failures == 0 ? "\nALL CHECKS PASSED" : "\n" + failures + " CHECK(S) FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
