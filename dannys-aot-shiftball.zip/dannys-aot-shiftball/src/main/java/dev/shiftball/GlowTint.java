package dev.shiftball;

import dev.shiftball.core.GlowMath;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;

/**
 * Wraps the vertex consumers a living entity is drawn with, so everything on it (body, clothes, armor)
 * is multiplied towards golden yellow and lit at full brightness while it glows. The wrapper only does
 * something while {@link ShiftBallManager#currentTint()} is above zero; otherwise it hands out the
 * original consumers untouched.
 */
public final class GlowTint {
    private GlowTint() {}

    public static VertexConsumerProvider wrap(VertexConsumerProvider delegate) {
        if (delegate == null || delegate instanceof Provider) return delegate;
        return new Provider(delegate);
    }

    private static final class Provider implements VertexConsumerProvider {
        private final VertexConsumerProvider delegate;

        Provider(VertexConsumerProvider delegate) {
            this.delegate = delegate;
        }

        @Override
        public VertexConsumer getBuffer(RenderLayer layer) {
            VertexConsumer c = delegate.getBuffer(layer);
            float t = ShiftBallManager.currentTint();
            return t > 0f ? new Consumer(c, t) : c;
        }
    }

    private static final class Consumer implements VertexConsumer {
        private final VertexConsumer d;
        private final float gMul, bMul, t;

        Consumer(VertexConsumer d, float t) {
            this.d = d;
            this.t = t;
            this.gMul = 1f + (GlowMath.TINT_G - 1f) * t;
            this.bMul = 1f + (GlowMath.TINT_B - 1f) * t;
        }

        @Override
        public VertexConsumer vertex(double x, double y, double z) {
            d.vertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer color(int red, int green, int blue, int alpha) {
            d.color(red, Math.round(green * gMul), Math.round(blue * bMul), alpha);
            return this;
        }

        @Override
        public VertexConsumer texture(float u, float v) {
            d.texture(u, v);
            return this;
        }

        @Override
        public VertexConsumer overlay(int u, int v) {
            d.overlay(u, v);
            return this;
        }

        /** Lightmap coordinates (0..240): pulled towards full brightness. */
        @Override
        public VertexConsumer light(int u, int v) {
            d.light(Math.round(u + (240 - u) * t), Math.round(v + (240 - v) * t));
            return this;
        }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            d.normal(x, y, z);
            return this;
        }
    }
}
