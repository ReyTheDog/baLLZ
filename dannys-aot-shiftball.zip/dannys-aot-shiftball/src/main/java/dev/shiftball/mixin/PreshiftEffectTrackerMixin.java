package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the shifter's preshift (biting the hand, lightning, chargeup sound) of Danny's AoT. Nothing is
 * cancelled: the mod's lightning and sounds play as normal and the addon adds a yellow glow on top.
 */
@Pseudo
@Mixin(targets = "daot.PreshiftEffectTracker")
public abstract class PreshiftEffectTrackerMixin {

    /** The local player starts charging up (onPreshiftConfirmed(boolean, boolean)). */
    @Inject(method = "onPreshiftConfirmed", at = @At("HEAD"), remap = false)
    private static void shiftball$localPreshift(boolean a, boolean b, CallbackInfo ci) {
        ShiftBallManager.onLocalPreshift();
    }

    /** Another player starts charging up (onOtherPlayerPreshift(int entityId, boolean)). */
    @Inject(method = "onOtherPlayerPreshift", at = @At("HEAD"), remap = false)
    private static void shiftball$otherPreshift(int entityId, boolean b, CallbackInfo ci) {
        ShiftBallManager.onOtherPreshift(entityId);
    }

    /** The mod cancels the whole charge-up (stopAllEffects). */
    @Inject(method = "stopAllEffects", at = @At("HEAD"), remap = false)
    private static void shiftball$stop(CallbackInfo ci) {
        ShiftBallManager.endPlayerGlows();
    }
}
