package dev.shiftball.mixin;

import dev.shiftball.GlowTint;
import dev.shiftball.ShiftBallManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Makes a charging-up shifter (or villager) actually glow yellow. While its model is drawn, the vertex
 * consumers it is drawn with are wrapped (see GlowTint) so the colour goes golden and the light goes to
 * full brightness. This only needs the method's own signature, no call inside it, so it keeps working
 * across small Minecraft changes. {@code require = 0}: if it ever stops matching, only the glow
 * disappears and the game still starts.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    private static final String RENDER =
            "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;I)V";

    /** Which entity is being drawn (the wrapper reads the glow level lazily, when the model asks for a buffer). */
    @Inject(method = RENDER, at = @At("HEAD"), require = 0)
    private void shiftball$begin(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                 VertexConsumerProvider consumers, int light, CallbackInfo ci) {
        ShiftBallManager.beginRender(entity.getId());
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void shiftball$end(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                               VertexConsumerProvider consumers, int light, CallbackInfo ci) {
        ShiftBallManager.endRender();
    }

    /** Swaps the provider argument for a wrapper (only while some glow is active, so normal frames cost nothing). */
    @ModifyVariable(method = RENDER, at = @At("HEAD"), argsOnly = true, require = 0)
    private VertexConsumerProvider shiftball$wrap(VertexConsumerProvider consumers) {
        return ShiftBallManager.hasGlows() ? GlowTint.wrap(consumers) : consumers;
    }
}
