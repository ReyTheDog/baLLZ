package dev.shiftball.mixin;

import dev.shiftball.ShiftBallClient;
import dev.shiftball.ShiftBallManager;
import dev.shiftball.core.ShiftBallConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels the mod's AAA-Particles effects that the ball replaces:
 * <ul>
 *   <li>the "shift" cloud (both the positional and the entity-bound version) whenever a ball is
 *       being shown or one of the spawn handlers is running;</li>
 *   <li>optionally the villager's "preshift" lightning, only while
 *       VillagerTransformEffectHandler#onVillagerTransformStart is running (and only if the user turned
 *       {@code pureTitanPreshiftBall} on). The shifter's own preshift is never touched.</li>
 * </ul>
 * The names match all overloads; no descriptors are written so there are no Minecraft types to remap.
 */
@Pseudo
@Mixin(targets = "daot.ShiftParticleHelper")
public abstract class ShiftParticleHelperMixin {

    @Inject(method = {"spawnShiftParticle", "spawnShiftParticleBoundToEntity"},
            at = @At("HEAD"), cancellable = true, remap = false)
    private static void shiftball$suppressCloud(CallbackInfo ci) {
        boolean cancel = ShiftBallManager.shouldSuppressCloud();
        if (ShiftBallConfig.debug) {
            ShiftBallClient.LOGGER.info("daot.ShiftParticleHelper.{} called from {} -> {}", ci.getId(), caller(),
                    cancel ? "cancelled" : "left running");
        }
        if (cancel) ci.cancel();
    }

    @Inject(method = "spawnPreshiftParticleBoundToEntity", at = @At("HEAD"), cancellable = true, remap = false)
    private static void shiftball$suppressPreshift(CallbackInfo ci) {
        boolean cancel = ShiftBallManager.shouldSuppressPreshift();
        if (ShiftBallConfig.debug) {
            ShiftBallClient.LOGGER.info("daot.ShiftParticleHelper.{} called from {} -> {}", ci.getId(), caller(),
                    cancel ? "cancelled" : "left running");
        }
        if (cancel) ci.cancel();
    }

    /** The two frames above this one are the target method and whoever called it. */
    private static String caller() {
        StackTraceElement[] st = new Throwable().getStackTrace();
        for (int i = 2; i < st.length && i < 6; i++) {
            String c = st[i].getClassName();
            if (!c.startsWith("daot.ShiftParticleHelper")) return c + "." + st[i].getMethodName();
        }
        return "?";
    }
}
