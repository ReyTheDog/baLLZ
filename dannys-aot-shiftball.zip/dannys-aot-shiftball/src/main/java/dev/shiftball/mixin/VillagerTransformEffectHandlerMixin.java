package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the pure-titan transformation handler of Danny's AoT (client side):
 * <ul>
 *   <li>onVillagerTransformStart(int villagerEntityId): the villager starts glowing (the mod's
 *       "preshift" effect, bound to the villager). Replaced by a ball around the villager.</li>
 *   <li>onTitanSpawnFromVillager(double x, double y, double z, int titanEntityId): the villager
 *       turns into the titan (the mod spawns a small shift cloud). Replaced by the titan's ball.</li>
 * </ul>
 */
@Pseudo
@Mixin(targets = "daot.VillagerTransformEffectHandler")
public abstract class VillagerTransformEffectHandlerMixin {

    @Inject(method = "onVillagerTransformStart", at = @At("HEAD"), remap = false)
    private static void shiftball$preshiftBegin(int villagerEntityId, CallbackInfo ci) {
        ShiftBallManager.onVillagerTransformStart(villagerEntityId);
    }

    @Inject(method = "onVillagerTransformStart", at = @At("RETURN"), remap = false)
    private static void shiftball$preshiftEnd(int villagerEntityId, CallbackInfo ci) {
        ShiftBallManager.endVillagerTransformStart();
    }

    @Inject(method = "onTitanSpawnFromVillager", at = @At("HEAD"), remap = false)
    private static void shiftball$begin(double x, double y, double z, int titanEntityId, CallbackInfo ci) {
        ShiftBallManager.onPureTitanSpawn(x, y, z, titanEntityId);
    }

    @Inject(method = "onTitanSpawnFromVillager", at = @At("RETURN"), remap = false)
    private static void shiftball$end(double x, double y, double z, int titanEntityId, CallbackInfo ci) {
        ShiftBallManager.endTitanSpawn();
    }
}
