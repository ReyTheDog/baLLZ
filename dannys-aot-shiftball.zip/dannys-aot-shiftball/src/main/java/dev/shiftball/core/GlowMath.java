package dev.shiftball.core;

/** How bright the preshift glow is. Pure Java so it can be tested without Minecraft. */
public final class GlowMath {
    private GlowMath() {}

    /** Share of the way to the transformation, 0..1. */
    public static float progress(float ageTicks, float durationTicks) {
        if (durationTicks <= 0f) return 1f;
        return Math.max(0f, Math.min(1f, ageTicks / durationTicks));
    }

    /** Smooth brightness without flicker: faint at the start, full at the transformation. Never decreases. */
    public static float base(float ageTicks, float durationTicks) {
        float p = progress(ageTicks, durationTicks);
        return 0.10f + 0.90f * (float) Math.pow(p, 1.5);
    }

    /** Brightness with a heartbeat-like pulse that speeds up as the transformation gets closer. */
    public static float brightness(float ageTicks, float durationTicks) {
        float p = progress(ageTicks, durationTicks);
        float pulse = 1f + 0.12f * (float) Math.sin(ageTicks * (0.5f + 1.5f * p));
        return Math.max(0f, Math.min(1.2f, base(ageTicks, durationTicks) * pulse));
    }

    /** Body colour multipliers at full glow: skin and light clothes turn golden yellow. */
    public static final float TINT_G = 0.80f, TINT_B = 0.18f;

    /** Multiplies an ARGB colour towards golden yellow; t = 0 leaves it alone, t = 1 is the full glow. Alpha is kept. */
    public static int tintColor(int argb, float t) {
        t = Math.max(0f, Math.min(1f, t));
        if (t <= 0f) return argb;
        float g = 1f + (TINT_G - 1f) * t, b = 1f + (TINT_B - 1f) * t;
        int a = (argb >>> 24) & 255, r = (argb >> 16) & 255;
        int gg = Math.round(((argb >> 8) & 255) * g), bb = Math.round((argb & 255) * b);
        return (a << 24) | (r << 16) | (gg << 8) | bb;
    }

    /** Pulls a packed light value (sky << 20 | block << 4) towards full brightness, so the body shines in the dark too. */
    public static int tintLight(int packed, float t) {
        t = Math.max(0f, Math.min(1f, t));
        if (t <= 0f) return packed;
        int sky = (packed >> 20) & 15, block = (packed >> 4) & 15;
        sky = Math.round(sky + (15 - sky) * t);
        block = Math.round(block + (15 - block) * t);
        return (sky << 20) | (block << 4);
    }

    /** Quick fade-out once the effect is over; 1 while running, 0 after {@code fadeTicks}. */
    public static float fade(float ticksSinceEnd, float fadeTicks) {
        if (ticksSinceEnd <= 0f) return 1f;
        if (ticksSinceEnd >= fadeTicks) return 0f;
        return 1f - ticksSinceEnd / fadeTicks;
    }
}
