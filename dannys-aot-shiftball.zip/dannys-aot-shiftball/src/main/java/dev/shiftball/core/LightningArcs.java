package dev.shiftball.core;

import java.util.Random;

/** Generates jagged lightning polylines that leave the surface of the ball. Pure Java. */
public final class LightningArcs {
    private LightningArcs() {}

    /**
     * @return (segments + 1) points as flat xyz, relative to the ball centre. The first point
     *         lies on a sphere of 0.92 * radius; the arc then runs outward with random jitter.
     */
    public static float[] arc(long seed, float radius, int segments) {
        Random rnd = new Random(seed);
        double ux, uy, uz, len;
        do {
            ux = rnd.nextGaussian();
            uy = rnd.nextGaussian();
            uz = rnd.nextGaussian();
            len = Math.sqrt(ux * ux + uy * uy + uz * uz);
        } while (len < 1e-6);
        ux /= len;
        uy /= len;
        uz /= len;

        float start = radius * 0.92f;
        float length = radius * (0.45f + 0.6f * rnd.nextFloat());
        float jitter = radius * 0.10f;

        float[] pts = new float[(segments + 1) * 3];
        for (int k = 0; k <= segments; k++) {
            float t = k / (float) segments;
            float d = start + length * t;
            float jx = (rnd.nextFloat() - 0.5f) * 2f * jitter;
            float jy = (rnd.nextFloat() - 0.5f) * 2f * jitter;
            float jz = (rnd.nextFloat() - 0.5f) * 2f * jitter;
            if (k == 0) {
                jx = 0f;
                jy = 0f;
                jz = 0f;
            }
            pts[k * 3] = (float) ux * d + jx;
            pts[k * 3 + 1] = (float) uy * d + jy;
            pts[k * 3 + 2] = (float) uz * d + jz;
        }
        return pts;
    }
}
