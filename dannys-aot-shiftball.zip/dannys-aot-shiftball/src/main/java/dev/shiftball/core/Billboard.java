package dev.shiftball.core;

/** Camera-facing strip geometry for the lightning. Pure Java so the winding can be tested. */
public final class Billboard {
    private Billboard() {}

    /**
     * A strip of width {@code 2 * half} between two points, turned to face the camera.
     *
     * The points are ball-local; (ox, oy, oz) is the ball centre relative to the camera, so the
     * camera is at (-ox, -oy, -oz) in ball-local space.
     *
     * The vanilla lightning render layer culls back faces. Which winding faces the camera depends on
     * the angle the strip is seen from, so BOTH windings are returned: 8 vertices (xyz each, 24
     * floats) - the quad, then the same quad reversed. One of the two always faces the camera.
     *
     * @return 24 floats, or null if the strip is degenerate (segment pointing straight at the camera)
     */
    public static float[] strip(float px, float py, float pz, float qx, float qy, float qz,
                                float ox, float oy, float oz, float half) {
        float dx = qx - px, dy = qy - py, dz = qz - pz;
        // View vector from the camera to the segment midpoint.
        float vx = ox + (px + qx) * 0.5f, vy = oy + (py + qy) * 0.5f, vz = oz + (pz + qz) * 0.5f;
        float sx = dy * vz - dz * vy;
        float sy = dz * vx - dx * vz;
        float sz = dx * vy - dy * vx;
        float len = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (len < 1e-6f) return null;
        float k = half / len;
        sx *= k;
        sy *= k;
        sz *= k;
        float ax = px - sx, ay = py - sy, az = pz - sz;
        float bx = px + sx, by = py + sy, bz = pz + sz;
        float cx = qx + sx, cy = qy + sy, cz = qz + sz;
        float ex = qx - sx, ey = qy - sy, ez = qz - sz;
        return new float[] {
                ax, ay, az, bx, by, bz, cx, cy, cz, ex, ey, ez, // quad
                ex, ey, ez, cx, cy, cz, bx, by, bz, ax, ay, az  // reversed
        };
    }
}
