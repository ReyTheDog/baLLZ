package dev.shiftball.core;

/** Pure math for the pulsing transformation ball (no Minecraft classes, unit-testable). */
public final class BallMath {
    private BallMath() {}

    /**
     * The sphere mesh is faceted, so its flat faces sit slightly inside the ideal sphere.
     * The mesh used by the renderer (18 segments x 12 rings) has an inradius of about 0.976;
     * scaling the outer shell by this factor guarantees its surface never dips inside the
     * covering radius. Verified in CoreCheck.
     */
    public static final float TESSELLATION = 1.03f;

    /** Flicker is +-2.5% of the radius; this is its lowest factor. */
    private static final float FLICKER_FLOOR = 0.975f;

    public static float smoothstep(float edge0, float edge1, float x) {
        float t = Math.min(1f, Math.max(0f, (x - edge0) / (edge1 - edge0)));
        return t * t * (3f - 2f * t);
    }

    /**
     * Radius of the smallest sphere centred on the hitbox that contains the whole hitbox
     * (half of its diagonal), times the safety factors. Everything inside this sphere is covered.
     */
    public static float coverRadius(double lengthX, double lengthY, double lengthZ,
                                    float coverage, float sizeMultiplier) {
        double halfDiagonal = 0.5 * Math.sqrt(lengthX * lengthX + lengthY * lengthY + lengthZ * lengthZ);
        return (float) (halfDiagonal * coverage * sizeMultiplier);
    }

    /**
     * Largest radius of the pulse, chosen so that the SMALLEST point of the pulse (minPulse,
     * with flicker at its lowest) is exactly the covering radius. The ball therefore grows and
     * shrinks, but never gets smaller than what is needed to hide the titan.
     */
    public static float fullRadius(float coverRadius, float minPulse) {
        return coverRadius / (minPulse * FLICKER_FLOOR);
    }

    /**
     * Radius factor of the ball, 0..~1.025.
     *
     * Shape over the transformation: it swells in during the first 8% (about 6 ticks), then keeps
     * shrinking and growing between {@code minPulse} and 1.0 (the pulse speeds up by up to 30%
     * towards the end, like the anime), and collapses during the last 12% to reveal the titan.
     *
     * @param ageTicks      ticks since the ball started (fractional)
     * @param durationTicks total lifetime in ticks
     * @param minPulse      smallest pulse size as a fraction of the full size (0.1..1)
     * @param pulseHz       pulses per second at the start
     */
    public static float scale(float ageTicks, float durationTicks, float minPulse, float pulseHz) {
        if (ageTicks <= 0f || ageTicks >= durationTicks) return 0f;
        float p = ageTicks / durationTicks;
        float grow = smoothstep(0f, 0.08f, p);
        float collapse = 1f - smoothstep(0.88f, 1f, p);
        float seconds = ageTicks / 20f;
        double phase = 2.0 * Math.PI * pulseHz * (seconds + 0.3 * seconds * p) - Math.PI / 2.0;
        float wave = 0.5f + 0.5f * (float) Math.sin(phase);
        float pulse = minPulse + (1f - minPulse) * wave;
        float flicker = 1f + 0.025f * (float) Math.sin(phase * 7.3);
        return grow * collapse * pulse * flicker;
    }
}
