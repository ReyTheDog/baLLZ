package dev.shiftball.core;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties-file config. Missing keys fall back to defaults and are written back. */
public final class ShiftBallConfig {
    private ShiftBallConfig() {}

    /** Master switch for the whole addon. */
    public static boolean enabled = true;
    /** Suppress the original AAA-Particles "shift" cloud and show the ball instead. */
    public static boolean replaceCloud = true;
    /** Also show the ball for the Colossal Titan (it keeps its own nuke effect either way). */
    public static boolean includeColossal = false;
    /** Draw the thin yellow lightning arcs around the ball. */
    public static boolean arcs = true;
    public static int arcCount = 6;
    /** Multiplier for arc thickness. */
    public static float arcWidth = 1.0f;
    /**
     * The ball never gets smaller than half the titan's hitbox diagonal * coverage (the smallest
     * sphere that contains the whole hitbox), so it always covers the titan. 1.1 leaves a margin
     * for arms and models that stick out of the hitbox.
     */
    public static float coverage = 1.1f;
    /** Extra manual size multiplier if a titan still sticks out (or the ball is too big). */
    public static float sizeMultiplier = 1.0f;
    /** Brightness/opaqueness of the ball. Raise towards 1.5 to hide the titan more strongly. */
    public static float opacity = 1.0f;
    /**
     * Smallest pulse size relative to the largest. The pulse's smallest size is the covering
     * radius, so a LOWER value means the ball gets BIGGER at its peak (more dramatic pulse);
     * 0.75 means it swells to about 1.37x the covering size.
     */
    public static float minPulse = 0.75f;
    /** Pulses per second at the start (speeds up towards the end). */
    public static float pulseHz = 1.6f;
    /** Do not draw the ball beyond this distance (blocks). */
    public static float maxDistance = 512f;
    /** Covering radius used if the titan entity cannot be found on the client (about a 15-block titan). */
    public static float fallbackRadius = 8.5f;
    /** Log ball sizes to the console. */
    public static boolean debug = false;

    public static void load(Path file) {
        Properties p = new Properties();
        if (Files.isRegularFile(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                p.load(r);
            } catch (IOException ignored) {
                // fall back to defaults
            }
        }
        enabled = bool(p, "enabled", enabled);
        replaceCloud = bool(p, "replaceCloud", replaceCloud);
        includeColossal = bool(p, "includeColossal", includeColossal);
        arcs = bool(p, "arcs", arcs);
        arcCount = Math.round(clamp(num(p, "arcCount", arcCount), 0f, 24f));
        arcWidth = clamp(num(p, "arcWidth", arcWidth), 0.1f, 5f);
        coverage = clamp(num(p, "coverage", coverage), 0.3f, 3f);
        sizeMultiplier = clamp(num(p, "sizeMultiplier", sizeMultiplier), 0.1f, 10f);
        opacity = clamp(num(p, "opacity", opacity), 0.2f, 3f);
        minPulse = clamp(num(p, "minPulse", minPulse), 0.1f, 1f);
        pulseHz = clamp(num(p, "pulseHz", pulseHz), 0.2f, 6f);
        maxDistance = clamp(num(p, "maxDistance", maxDistance), 16f, 4096f);
        fallbackRadius = clamp(num(p, "fallbackRadius", fallbackRadius), 0.5f, 100f);
        debug = bool(p, "debug", debug);
        write(file);
    }

    private static void write(Path file) {
        String s = "# Danny's AoT - Titan Shift Ball config\n"
                + "enabled=" + enabled + "\n"
                + "# Hide the original (laggy) shift cloud and show the ball instead\n"
                + "replaceCloud=" + replaceCloud + "\n"
                + "# Also show the ball for the Colossal Titan\n"
                + "includeColossal=" + includeColossal + "\n"
                + "# Thin yellow lightning arcs around the ball\n"
                + "arcs=" + arcs + "\n"
                + "arcCount=" + arcCount + "\n"
                + "arcWidth=" + arcWidth + "\n"
                + "# The ball never gets smaller than half the titan hitbox diagonal * coverage * sizeMultiplier\n"
                + "# (the smallest sphere that contains the whole titan). Raise them if anything sticks out.\n"
                + "coverage=" + coverage + "\n"
                + "sizeMultiplier=" + sizeMultiplier + "\n"
                + "# Brightness of the ball (raise to hide the titan more strongly)\n"
                + "opacity=" + opacity + "\n"
                + "# Smallest pulse as a fraction of the largest. The smallest pulse = covering size, so\n"
                + "# a lower value makes the ball swell bigger at its peak\n"
                + "minPulse=" + minPulse + "\n"
                + "# Pulses per second at the start (speeds up towards the end)\n"
                + "pulseHz=" + pulseHz + "\n"
                + "maxDistance=" + maxDistance + "\n"
                + "fallbackRadius=" + fallbackRadius + "\n"
                + "debug=" + debug + "\n";
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, s);
        } catch (IOException ignored) {
            // read-only config dir is fine
        }
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    private static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
