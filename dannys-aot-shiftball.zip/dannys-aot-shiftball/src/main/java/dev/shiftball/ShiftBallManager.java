package dev.shiftball;

import dev.shiftball.core.ShiftBallConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Tracks active balls and decides when the original shift cloud is suppressed. Client thread only. */
public final class ShiftBallManager {
    private ShiftBallManager() {}

    /** Matches daot.network.TitanSpawnPayload.TYPE_COLOSSAL. */
    private static final int TYPE_COLOSSAL = 6;
    /** Matches the transformation ticks the mod sets on the server (80, Colossal 95). */
    private static final float DURATION_NORMAL = 80f;
    private static final float DURATION_COLOSSAL = 95f;
    private static final int MAX_BALLS = 16;

    private static final List<ShiftBall> BALLS = new ArrayList<>();
    private static boolean suppressCloud = false;
    private static long counter = 0;

    /** Called from the mixin at the start of TitanShiftSoundHandler.onTitanSpawn. */
    public static void onTitanSpawn(double x, double y, double z, int titanEntityId, int titanType) {
        suppressCloud = false;
        if (!ShiftBallConfig.enabled) return;
        if (titanType == TYPE_COLOSSAL && !ShiftBallConfig.includeColossal) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        // Only the shifter path gets the cloud suppressed; villager transformations call
        // ShiftParticleHelper directly and are left alone.
        suppressCloud = ShiftBallConfig.replaceCloud;

        float duration = titanType == TYPE_COLOSSAL ? DURATION_COLOSSAL : DURATION_NORMAL;
        long seed = System.nanoTime() ^ (++counter * 0x9E3779B97F4A7C15L);
        BALLS.add(new ShiftBall(titanEntityId, new Vec3d(x, y + 1.0, z), duration, seed));
        while (BALLS.size() > MAX_BALLS) BALLS.remove(0);
    }

    /** Called from the mixin when onTitanSpawn returns. */
    public static void endTitanSpawn() {
        suppressCloud = false;
    }

    /** Asked by the ShiftParticleHelper mixin: true only while inside the shifter spawn handler. */
    public static boolean shouldSuppressCloud() {
        return suppressCloud;
    }

    static List<ShiftBall> active() {
        return BALLS;
    }

    public static void tick() {
        if (BALLS.isEmpty()) return;
        long now = System.nanoTime();
        BALLS.removeIf(b -> b.dead || b.ageTicks(now) >= b.durationTicks);
    }

    public static void clear() {
        BALLS.clear();
        suppressCloud = false;
    }
}
