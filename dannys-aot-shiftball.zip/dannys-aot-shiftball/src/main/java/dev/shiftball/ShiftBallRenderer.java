package dev.shiftball;

import dev.shiftball.core.BallMath;
import dev.shiftball.core.LightningArcs;
import dev.shiftball.core.ShiftBallConfig;
import dev.shiftball.core.SphereMesh;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Random;

/**
 * Draws the glowing, pulsing yellow ball (three nested shells + thin lightning arcs) with the
 * vanilla additive "lightning" render layer. A few thousand vertices per ball - far cheaper than
 * a particle cloud.
 */
public final class ShiftBallRenderer {
    private ShiftBallRenderer() {}

    private static final SphereMesh MESH = new SphereMesh(18, 12);
    private static final int ARC_SEGMENTS = 7;

    public static void render(WorldRenderContext ctx) {
        List<ShiftBall> balls = ShiftBallManager.active();
        if (balls.isEmpty()) return;

        VertexConsumerProvider consumers = ctx.consumers();
        MatrixStack matrices = ctx.matrixStack();
        ClientWorld world = ctx.world();
        if (consumers == null || matrices == null || world == null) return;

        Vec3d cam = ctx.camera().getPos();
        long now = System.nanoTime();
        double maxDist2 = (double) ShiftBallConfig.maxDistance * ShiftBallConfig.maxDistance;
        VertexConsumer buf = consumers.getBuffer(RenderLayer.getLightning());
        boolean drewAnything = false;

        for (ShiftBall b : balls) {
            float age = b.ageTicks(now);
            float scale = BallMath.scale(age, b.durationTicks, ShiftBallConfig.minPulse, ShiftBallConfig.pulseHz);
            if (scale <= 0f) continue;

            // Follow the real titan so the ball always covers it, whatever its size.
            Entity e = world.getEntityById(b.entityId);
            if (e != null) {
                if (e.isRemoved()) {
                    b.dead = true;
                    continue;
                }
                Box bb = e.getBoundingBox();
                b.lastCenter = bb.getCenter();
                // Smallest sphere around the hitbox; the pulse never goes below this size.
                float cover = BallMath.coverRadius(bb.getLengthX(), bb.getLengthY(), bb.getLengthZ(),
                        ShiftBallConfig.coverage, ShiftBallConfig.sizeMultiplier);
                b.maxRadius = Math.max(b.maxRadius, BallMath.fullRadius(cover, ShiftBallConfig.minPulse));
            } else if (b.maxRadius <= 0f) {
                // The titan entity may arrive a moment after the spawn packet: wait up to half a
                // second for it so the ball is sized from the real hitbox, then use the fallback.
                if (age < 10f) continue;
                float cover = ShiftBallConfig.fallbackRadius * ShiftBallConfig.sizeMultiplier;
                b.maxRadius = BallMath.fullRadius(cover, ShiftBallConfig.minPulse);
            }
            if (ShiftBallConfig.debug && !b.logged && b.maxRadius > 0f) {
                b.logged = true;
                ShiftBallClient.LOGGER.info("Shift ball for entity {}: full radius {} (entity found: {})",
                        b.entityId, b.maxRadius, e != null);
            }

            float radius = b.maxRadius * scale;
            if (radius < 0.05f) continue;

            Vec3d c = b.lastCenter;
            double dx = c.x - cam.x, dy = c.y - cam.y, dz = c.z - cam.z;
            if (dx * dx + dy * dy + dz * dz > maxDist2) continue;

            matrices.push();
            matrices.translate(dx, dy, dz);
            Matrix4f m = matrices.peek().getPositionMatrix();

            // Inner shells are drawn first so the nearer outer shell still passes the depth test.
            // The outer shell is the one that must cover the titan, so it is strong, and scaled up
            // slightly so the flat faces of the mesh never dip inside the covering radius.
            float flicker = 0.9f + 0.1f * (float) Math.sin(age * 1.7f);
            float op = ShiftBallConfig.opacity;
            shell(buf, m, radius * 0.60f, 1.00f, 0.97f, 0.65f, a(0.70f * flicker * op)); // white-hot core
            shell(buf, m, radius * 0.85f, 1.00f, 0.88f, 0.22f, a(0.45f * op));           // golden middle
            shell(buf, m, radius * BallMath.TESSELLATION, 1.00f, 0.78f, 0.10f, a(0.60f * op)); // yellow shell

            if (ShiftBallConfig.arcs && ShiftBallConfig.arcCount > 0) {
                arcs(buf, m, b, age, radius, (float) dx, (float) dy, (float) dz);
            }
            matrices.pop();
            drewAnything = true;
        }

        if (drewAnything && consumers instanceof VertexConsumerProvider.Immediate immediate) {
            immediate.draw(RenderLayer.getLightning());
        }
    }

    private static float a(float alpha) {
        return Math.min(1f, Math.max(0f, alpha));
    }

    /** Emits a sphere shell with both windings so it is visible from inside (the shifter's own view). */
    private static void shell(VertexConsumer buf, Matrix4f m, float r, float cr, float cg, float cb, float ca) {
        float[] q = MESH.quads;
        for (int i = 0; i < MESH.quadCount; i++) {
            int o = i * 12;
            for (int k = 0; k < 4; k++) {
                vertex(buf, m, q[o + k * 3] * r, q[o + k * 3 + 1] * r, q[o + k * 3 + 2] * r, cr, cg, cb, ca);
            }
            for (int k = 3; k >= 0; k--) {
                vertex(buf, m, q[o + k * 3] * r, q[o + k * 3 + 1] * r, q[o + k * 3 + 2] * r, cr, cg, cb, ca);
            }
        }
    }

    private static void arcs(VertexConsumer buf, Matrix4f m, ShiftBall b, float age, float radius,
                             float ox, float oy, float oz) {
        // Re-roll the arcs every 2 ticks so they flicker like real lightning.
        long step = (long) (age / 2f);
        float glowHalf = Math.max(0.04f, radius * 0.020f * ShiftBallConfig.arcWidth);
        float coreHalf = Math.max(0.015f, radius * 0.007f * ShiftBallConfig.arcWidth);

        for (int a = 0; a < ShiftBallConfig.arcCount; a++) {
            long seed = b.seed * 31L + a * 7919L + step * 104729L;
            if (new Random(seed ^ 0x5DEECE66DL).nextFloat() < 0.25f) continue; // random dropouts
            float[] pts = LightningArcs.arc(seed, radius, ARC_SEGMENTS);
            for (int k = 0; k < ARC_SEGMENTS; k++) {
                float px = pts[k * 3], py = pts[k * 3 + 1], pz = pts[k * 3 + 2];
                float qx = pts[k * 3 + 3], qy = pts[k * 3 + 4], qz = pts[k * 3 + 5];
                strip(buf, m, px, py, pz, qx, qy, qz, ox, oy, oz, glowHalf, 1.00f, 0.88f, 0.25f, 0.35f);
                strip(buf, m, px, py, pz, qx, qy, qz, ox, oy, oz, coreHalf, 1.00f, 1.00f, 0.85f, 0.95f);
            }
        }
    }

    /** A camera-facing quad strip between two points (ball-local); o* is the ball offset from the camera. */
    private static void strip(VertexConsumer buf, Matrix4f m,
                              float px, float py, float pz, float qx, float qy, float qz,
                              float ox, float oy, float oz, float half,
                              float cr, float cg, float cb, float ca) {
        float dx = qx - px, dy = qy - py, dz = qz - pz;
        // View vector from the camera (origin) to the segment midpoint.
        float vx = ox + (px + qx) * 0.5f, vy = oy + (py + qy) * 0.5f, vz = oz + (pz + qz) * 0.5f;
        float sx = dy * vz - dz * vy;
        float sy = dz * vx - dx * vz;
        float sz = dx * vy - dy * vx;
        float len = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (len < 1e-6f) return;
        float k = half / len;
        sx *= k;
        sy *= k;
        sz *= k;
        vertex(buf, m, px - sx, py - sy, pz - sz, cr, cg, cb, ca);
        vertex(buf, m, px + sx, py + sy, pz + sz, cr, cg, cb, ca);
        vertex(buf, m, qx + sx, qy + sy, qz + sz, cr, cg, cb, ca);
        vertex(buf, m, qx - sx, qy - sy, qz - sz, cr, cg, cb, ca);
    }

    private static void vertex(VertexConsumer buf, Matrix4f m, float x, float y, float z,
                               float r, float g, float bl, float a) {
        buf.vertex(m, x, y, z).color(r, g, bl, a);
    }
}
