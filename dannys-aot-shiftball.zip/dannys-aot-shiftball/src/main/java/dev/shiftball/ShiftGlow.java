package dev.shiftball;

/** One entity glowing yellow during its preshift. Client thread only. */
final class ShiftGlow {
    static final float FADE_TICKS = 4f;

    final int entityId;
    final long startNanos;
    final float durationTicks;
    final long seed;
    /** True for a villager (ends by itself); false for a player (ends when the titan appears). */
    final boolean villager;
    /** 0 while running; the time the glow was told to end. */
    long endedNanos = 0L;
    /** Last known position of the entity, used for interpolation. */
    boolean dead = false;

    ShiftGlow(int entityId, float durationTicks, long seed, boolean villager) {
        this.entityId = entityId;
        this.durationTicks = durationTicks;
        this.seed = seed;
        this.villager = villager;
        this.startNanos = System.nanoTime();
    }

    float ageTicks(long now) {
        return (now - startNanos) / 50_000_000f;
    }

    float ticksSinceEnd(long now) {
        return endedNanos == 0L ? 0f : (now - endedNanos) / 50_000_000f;
    }

    boolean finished(long now) {
        if (dead) return true;
        if (endedNanos != 0L && ticksSinceEnd(now) >= FADE_TICKS) return true;
        return ageTicks(now) >= durationTicks + FADE_TICKS;
    }
}
