package dev.shiftball.mixin;

import dev.shiftball.ShiftBallManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels the mod's AAA-Particles effects, but only inside the handlers we replace:
 * <ul>
 *   <li>the "shift" cloud, only while TitanShiftSoundHandler#onTitanSpawn or
 *       VillagerTransformEffectHandler#onTitanSpawnFromVillager is running;</li>
 *   <li>the villager's "preshift" glow, only while VillagerTransformEffectHandler#onVillagerTransformStart
 *       is running. The shifter's own preshift (biting the hand) is left alone.</li>
 * </ul>
 * The names match all overloads; no descriptors are written so there are no Minecraft types to remap.
 */
@Pseudo
@Mixin(targets = "daot.ShiftParticleHelper")
public abstract class ShiftParticleHelperMixin {

    @Inject(method = "spawnShiftParticle", at = @At("HEAD"), cancellable = true, remap = false)
    private static void shiftball$suppressCloud(CallbackInfo ci) {
        if (ShiftBallManager.shouldSuppressCloud()) {
            ci.cancel();
        }
    }

    @Inject(method = "spawnPreshiftParticleBoundToEntity", at = @At("HEAD"), cancellable = true, remap = false)
    private static void shiftball$suppressPreshift(CallbackInfo ci) {
        if (ShiftBallManager.shouldSuppressPreshift()) {
            ci.cancel();
        }
    }
}
