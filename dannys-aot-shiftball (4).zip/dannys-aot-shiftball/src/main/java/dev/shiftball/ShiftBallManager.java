package dev.shiftball;

import dev.shiftball.core.GlowMath;
import dev.shiftball.core.ShiftBallConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Tracks active balls and decides when the mod's original effects are suppressed. Client thread only. */
public final class ShiftBallManager {
    private ShiftBallManager() {}

    /** Matches daot.network.TitanSpawnPayload.TYPE_COLOSSAL. */
    private static final int TYPE_COLOSSAL = 6;
    /** Matches the transformation ticks the mod sets on the server (80, Colossal 95). */
    private static final float DURATION_NORMAL = 80f;
    private static final float DURATION_COLOSSAL = 95f;
    private static final int MAX_BALLS = 16;

    /** Matches TOTAL_DURATION_TICKS in daot.PreshiftEffectTracker. */
    private static final float PLAYER_PRESHIFT_TICKS = 80f;

    private static final List<ShiftBall> BALLS = new ArrayList<>();
    private static final List<ShiftGlow> GLOWS = new ArrayList<>();
    private static long lastTickNanos = System.nanoTime();
    private static boolean suppressCloud = false;
    private static boolean suppressPreshift = false;
    private static long counter = 0;

    /** Called from the mixin at the start of TitanShiftSoundHandler.onTitanSpawn (shifters). */
    public static void onTitanSpawn(double x, double y, double z, int titanEntityId, int titanType) {
        suppressCloud = false;
        if (!ShiftBallConfig.enabled) return;
        if (titanType == TYPE_COLOSSAL && !ShiftBallConfig.includeColossal) return;
        startAt(x, y, z, titanEntityId, titanType == TYPE_COLOSSAL ? DURATION_COLOSSAL : DURATION_NORMAL);
    }

    /** Called from the mixin at the start of VillagerTransformEffectHandler.onTitanSpawnFromVillager (pure titan appears). */
    public static void onPureTitanSpawn(double x, double y, double z, int titanEntityId) {
        suppressCloud = false;
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.includePureTitans) return;
        startAt(x, y, z, titanEntityId, ShiftBallConfig.pureTitanDuration);
    }

    /**
     * Called from the mixin at the start of VillagerTransformEffectHandler.onVillagerTransformStart:
     * the villager starts glowing (the mod's "preshift" effect). We replace that effect with a ball
     * around the villager for the duration of the preshift.
     */
    public static void onVillagerTransformStart(int villagerEntityId) {
        suppressPreshift = false;
        if (!ShiftBallConfig.enabled) return;
        if (ShiftBallConfig.glow && ShiftBallConfig.glowVillagers) {
            startGlow(villagerEntityId, ShiftBallConfig.pureTitanPreshiftDuration, true);
        }
        if (!ShiftBallConfig.includePureTitans || !ShiftBallConfig.pureTitanPreshiftBall) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Entity villager = mc.world.getEntityById(villagerEntityId);
        if (villager == null) return;
        suppressPreshift = ShiftBallConfig.replaceCloud;
        add(new ShiftBall(villagerEntityId, villager.getPos().add(0.0, 1.0, 0.0),
                ShiftBallConfig.pureTitanPreshiftDuration, nextSeed(), true));
    }

    /** The local player begins the shifter preshift (lightning + chargeup sound): start glowing. */
    public static void onLocalPreshift() {
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.glow || !ShiftBallConfig.glowPlayers) return;
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null || p.hasVehicle()) return; // the mod ignores a preshift while riding a titan
        startGlow(p.getId(), PLAYER_PRESHIFT_TICKS, false);
    }

    /** Another player begins the shifter preshift. */
    public static void onOtherPreshift(int entityId) {
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.glow || !ShiftBallConfig.glowPlayers) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Entity e = mc.world.getEntityById(entityId);
        if (e != null && e.hasVehicle()) return;
        startGlow(entityId, PLAYER_PRESHIFT_TICKS, false);
    }

    private static void startGlow(int entityId, float durationTicks, boolean villager) {
        if (ShiftBallConfig.debug) ShiftBallClient.LOGGER.info("Glow: started for entity {} ({} ticks, villager={})", entityId, durationTicks, villager);
        GLOWS.removeIf(g -> g.entityId == entityId);
        GLOWS.add(new ShiftGlow(entityId, durationTicks, nextSeed(), villager));
        while (GLOWS.size() > MAX_BALLS) GLOWS.remove(0);
    }

    /** The titan appeared (or the charge-up was cancelled): players stop glowing with a quick fade. */
    public static void endPlayerGlows() {
        long now = System.nanoTime();
        for (ShiftGlow g : GLOWS) {
            if (!g.villager && g.endedNanos == 0L) g.endedNanos = now;
        }
    }

    private static void startAt(double x, double y, double z, int titanEntityId, float durationTicks) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        // The cloud is only suppressed while one of the spawn handlers is running, so nothing
        // else that uses ShiftParticleHelper is affected.
        suppressCloud = ShiftBallConfig.replaceCloud;
        add(new ShiftBall(titanEntityId, new Vec3d(x, y + 1.0, z), durationTicks, nextSeed(), false));
    }

    private static long nextSeed() {
        return System.nanoTime() ^ (++counter * 0x9E3779B97F4A7C15L);
    }

    private static void add(ShiftBall ball) {
        BALLS.add(ball);
        while (BALLS.size() > MAX_BALLS) BALLS.remove(0);
    }

    /** Called from the mixins when a spawn handler returns. */
    public static void endTitanSpawn() {
        suppressCloud = false;
    }

    /** Called from the mixin when onVillagerTransformStart returns. */
    public static void endVillagerTransformStart() {
        suppressPreshift = false;
    }

    /**
     * Asked by the ShiftParticleHelper mixin: true while inside one of the spawn handlers, and also
     * while a transformation ball is still being shown (so a cloud spawned a moment later is hidden too).
     */
    public static boolean shouldSuppressCloud() {
        if (suppressCloud) return true;
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.replaceCloud) return false;
        for (ShiftBall b : BALLS) {
            if (!b.keepWhenRemoved) return true;
        }
        return false;
    }

    /** Asked by the ShiftParticleHelper mixin: true only while inside onVillagerTransformStart. */
    public static boolean shouldSuppressPreshift() {
        return suppressPreshift;
    }

    static List<ShiftBall> active() {
        return BALLS;
    }

    // ---- body tint (used by LivingEntityRendererMixin while one entity is being rendered) ----
    private static float renderTint = 0f;
    private static int lastLoggedTintEntity = Integer.MIN_VALUE;

    /** Current glow level (0..1) of an entity, 0 if it is not glowing. */
    static float glowLevel(int entityId) {
        if (GLOWS.isEmpty() || !ShiftBallConfig.enabled || !ShiftBallConfig.glow) return 0f;
        long now = System.nanoTime();
        for (ShiftGlow g : GLOWS) {
            if (g.entityId != entityId || g.finished(now)) continue;
            float level = GlowMath.brightness(g.ageTicks(now), g.durationTicks)
                    * GlowMath.fade(g.ticksSinceEnd(now), ShiftGlow.FADE_TICKS) * ShiftBallConfig.glowIntensity;
            return Math.max(0f, Math.min(1f, level));
        }
        return 0f;
    }

    /** Called when the game starts drawing a living entity's body. */
    public static void beginRender(int entityId) {
        renderTint = ShiftBallConfig.glowTint ? glowLevel(entityId) : 0f;
        if (renderTint > 0f && ShiftBallConfig.debug && entityId != lastLoggedTintEntity) {
            lastLoggedTintEntity = entityId;
            ShiftBallClient.LOGGER.info("Glow: tinting entity {} (level {})", entityId, renderTint);
        }
    }

    public static void endRender() {
        renderTint = 0f;
    }

    /** Glow level of the entity currently being drawn (0 = none). */
    public static float currentTint() {
        return renderTint;
    }

    public static boolean hasGlows() {
        return !GLOWS.isEmpty() && ShiftBallConfig.enabled && ShiftBallConfig.glow && ShiftBallConfig.glowTint;
    }

    static List<ShiftGlow> activeGlows() {
        return GLOWS;
    }

    /** Fraction of the current game tick that has passed (for smooth movement between ticks). */
    static float partialTick(long now) {
        return Math.max(0f, Math.min(1f, (now - lastTickNanos) / 50_000_000f));
    }

    public static void tick() {
        long now = System.nanoTime();
        lastTickNanos = now;
        if (!BALLS.isEmpty()) BALLS.removeIf(b -> b.dead || b.ageTicks(now) >= b.durationTicks);
        if (!GLOWS.isEmpty()) GLOWS.removeIf(g -> g.finished(now));
    }

    public static void clear() {
        BALLS.clear();
        GLOWS.clear();
        suppressCloud = false;
        suppressPreshift = false;
    }
}
