package dev.shiftball;

import dev.shiftball.core.ShiftBallConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Tracks active balls and decides when the mod's original effects are suppressed. Client thread only. */
public final class ShiftBallManager {
    private ShiftBallManager() {}

    /** Matches daot.network.TitanSpawnPayload.TYPE_COLOSSAL. */
    private static final int TYPE_COLOSSAL = 6;
    /** Matches the transformation ticks the mod sets on the server (80, Colossal 95). */
    private static final float DURATION_NORMAL = 80f;
    private static final float DURATION_COLOSSAL = 95f;
    private static final int MAX_BALLS = 16;

    private static final List<ShiftBall> BALLS = new ArrayList<>();
    private static boolean suppressCloud = false;
    private static boolean suppressPreshift = false;
    private static long counter = 0;

    /** Called from the mixin at the start of TitanShiftSoundHandler.onTitanSpawn (shifters). */
    public static void onTitanSpawn(double x, double y, double z, int titanEntityId, int titanType) {
        suppressCloud = false;
        if (!ShiftBallConfig.enabled) return;
        if (titanType == TYPE_COLOSSAL && !ShiftBallConfig.includeColossal) return;
        startAt(x, y, z, titanEntityId, titanType == TYPE_COLOSSAL ? DURATION_COLOSSAL : DURATION_NORMAL);
    }

    /** Called from the mixin at the start of VillagerTransformEffectHandler.onTitanSpawnFromVillager (pure titan appears). */
    public static void onPureTitanSpawn(double x, double y, double z, int titanEntityId) {
        suppressCloud = false;
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.includePureTitans) return;
        startAt(x, y, z, titanEntityId, ShiftBallConfig.pureTitanDuration);
    }

    /**
     * Called from the mixin at the start of VillagerTransformEffectHandler.onVillagerTransformStart:
     * the villager starts glowing (the mod's "preshift" effect). We replace that effect with a ball
     * around the villager for the duration of the preshift.
     */
    public static void onVillagerTransformStart(int villagerEntityId) {
        suppressPreshift = false;
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.includePureTitans || !ShiftBallConfig.pureTitanPreshiftBall) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Entity villager = mc.world.getEntityById(villagerEntityId);
        if (villager == null) return;
        suppressPreshift = ShiftBallConfig.replaceCloud;
        add(new ShiftBall(villagerEntityId, villager.getPos().add(0.0, 1.0, 0.0),
                ShiftBallConfig.pureTitanPreshiftDuration, nextSeed(), true));
    }

    private static void startAt(double x, double y, double z, int titanEntityId, float durationTicks) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        // The cloud is only suppressed while one of the spawn handlers is running, so nothing
        // else that uses ShiftParticleHelper is affected.
        suppressCloud = ShiftBallConfig.replaceCloud;
        add(new ShiftBall(titanEntityId, new Vec3d(x, y + 1.0, z), durationTicks, nextSeed(), false));
    }

    private static long nextSeed() {
        return System.nanoTime() ^ (++counter * 0x9E3779B97F4A7C15L);
    }

    private static void add(ShiftBall ball) {
        BALLS.add(ball);
        while (BALLS.size() > MAX_BALLS) BALLS.remove(0);
    }

    /** Called from the mixins when a spawn handler returns. */
    public static void endTitanSpawn() {
        suppressCloud = false;
    }

    /** Called from the mixin when onVillagerTransformStart returns. */
    public static void endVillagerTransformStart() {
        suppressPreshift = false;
    }

    /** Asked by the ShiftParticleHelper mixin: true only while inside one of the spawn handlers. */
    public static boolean shouldSuppressCloud() {
        return suppressCloud;
    }

    /** Asked by the ShiftParticleHelper mixin: true only while inside onVillagerTransformStart. */
    public static boolean shouldSuppressPreshift() {
        return suppressPreshift;
    }

    static List<ShiftBall> active() {
        return BALLS;
    }

    public static void tick() {
        if (BALLS.isEmpty()) return;
        long now = System.nanoTime();
        BALLS.removeIf(b -> b.dead || b.ageTicks(now) >= b.durationTicks);
    }

    public static void clear() {
        BALLS.clear();
        suppressCloud = false;
        suppressPreshift = false;
    }
}
