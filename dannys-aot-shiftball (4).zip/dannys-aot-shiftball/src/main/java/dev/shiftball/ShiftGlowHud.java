package dev.shiftball;

import dev.shiftball.core.ShiftBallConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * First-person view: your own body is not drawn, so the glow is shown as a golden light over the screen
 * (a warm tint plus brighter edges) that gets stronger the closer the transformation is.
 */
public final class ShiftGlowHud {
    private ShiftGlowHud() {}

    private static final int RGB = 0xFFC81E;
    private static final int STRIPS = 14;

    public static void render(DrawContext ctx) {
        if (!ShiftBallConfig.enabled || !ShiftBallConfig.glow || !ShiftBallConfig.glowScreen) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.gameRenderer == null || mc.gameRenderer.getCamera().isThirdPerson()) return;
        float level = ShiftBallManager.glowLevel(mc.player.getId());
        if (level <= 0.02f) return;

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        // Warm tint over everything.
        ctx.fill(0, 0, w, h, argb(0.26f * level, RGB));

        // Brighter edges, fading towards the middle.
        int band = Math.round(Math.min(w, h) * 0.30f);
        int step = Math.max(1, band / STRIPS);
        for (int i = 0; i < STRIPS; i++) {
            float f = 1f - i / (float) STRIPS;
            int c = argb(0.55f * level * f * f, RGB);
            int o = i * step;
            ctx.fill(0, o, w, o + step, c);                 // top
            ctx.fill(0, h - o - step, w, h - o, c);         // bottom
            ctx.fill(o, 0, o + step, h, c);                 // left
            ctx.fill(w - o - step, 0, w - o, h, c);         // right
        }
    }

    private static int argb(float alpha, int rgb) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | rgb;
    }
}
