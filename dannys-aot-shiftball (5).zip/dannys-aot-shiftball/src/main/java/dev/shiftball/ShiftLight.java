package dev.shiftball;

import dev.shiftball.core.LightMath;
import dev.shiftball.core.ShiftBallConfig;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Real light for the transformation. Whoever is charging up, and every transformation ball, gets an
 * invisible vanilla "light" block placed in the air next to it on THIS client only (the server is never
 * told), so the game's own light engine lights up caves and dark rooms. The block is moved or removed
 * every tick, and only ever replaces air.
 */
final class ShiftLight {
    private ShiftLight() {}

    private static final class Placed {
        final BlockState original;
        int level = -1;
        Placed(BlockState original) {
            this.original = original;
        }
    }

    private static final Map<BlockPos, Placed> PLACED = new HashMap<>();
    private static ClientWorld lastWorld;
    private static final int[][] OFFSETS = {
            {0, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 2, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}
    };

    static void update() {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world != lastWorld) {
            PLACED.clear(); // another world: nothing of ours is in it
            lastWorld = world;
        }
        if (world == null) return;

        Map<BlockPos, Integer> want = new HashMap<>();
        int max = ShiftBallConfig.dynamicLightMax;
        if (ShiftBallConfig.enabled && ShiftBallConfig.dynamicLight && max > 0) {
            long now = System.nanoTime();
            for (ShiftGlow g : ShiftBallManager.activeGlows()) {
                if (g.finished(now)) continue;
                Entity e = world.getEntityById(g.entityId);
                if (e == null || e.isRemoved()) continue;
                int lvl = LightMath.glowLight(ShiftBallManager.glowLevel(g.entityId), max);
                add(world, want, BlockPos.ofFloored(e.getEyePos()), lvl);
            }
            for (ShiftBall b : ShiftBallManager.active()) {
                if (b.dead || b.lastCenter == null) continue;
                int lvl = LightMath.ballLight(b.ageTicks(now), b.durationTicks, max);
                add(world, want, BlockPos.ofFloored(b.lastCenter), lvl);
            }
        }
        apply(world, want);
    }

    private static void add(ClientWorld world, Map<BlockPos, Integer> want, BlockPos base, int level) {
        if (level <= 0) return;
        for (int[] o : OFFSETS) {
            BlockPos p = base.add(o[0], o[1], o[2]);
            if (PLACED.containsKey(p) || world.getBlockState(p).isAir()) {
                want.merge(p, level, Math::max);
                return;
            }
        }
    }

    private static void apply(ClientWorld world, Map<BlockPos, Integer> want) {
        Iterator<Map.Entry<BlockPos, Placed>> it = PLACED.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Placed> en = it.next();
            if (!want.containsKey(en.getKey())) {
                restore(world, en.getKey(), en.getValue());
                it.remove();
            }
        }
        for (Map.Entry<BlockPos, Integer> w : want.entrySet()) {
            BlockPos pos = w.getKey();
            int level = w.getValue();
            Placed placed = PLACED.get(pos);
            if (placed == null) {
                BlockState original = world.getBlockState(pos);
                if (!original.isAir()) continue;
                placed = new Placed(original);
                PLACED.put(pos.toImmutable(), placed);
            }
            if (placed.level != level) {
                world.setBlockState(pos, Blocks.LIGHT.getDefaultState().with(Properties.LEVEL_15, level),
                        Block.NOTIFY_LISTENERS);
                placed.level = level;
            }
        }
    }

    private static void restore(ClientWorld world, BlockPos pos, Placed placed) {
        // Only take back our own light block, never something that replaced it meanwhile.
        if (world.getBlockState(pos).isOf(Blocks.LIGHT)) {
            world.setBlockState(pos, placed.original, Block.NOTIFY_LISTENERS);
        }
    }

    /** Removes every light block we placed (disconnect, or the addon being switched off). */
    static void clear() {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world != null && world == lastWorld) {
            try {
                for (Map.Entry<BlockPos, Placed> en : PLACED.entrySet()) restore(world, en.getKey(), en.getValue());
            } catch (RuntimeException ignored) {
                // leaving the world: nothing to clean
            }
        }
        PLACED.clear();
    }
}
