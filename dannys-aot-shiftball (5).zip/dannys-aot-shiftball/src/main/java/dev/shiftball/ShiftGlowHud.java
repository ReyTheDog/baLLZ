package dev.shiftball;

import dev.shiftball.core.ShiftBallConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * First-person view: your own body is not drawn, so the glow is shown as a golden light over the screen
 * (a warm tint plus brighter edges) that gets stronger the closer the transformation is.
 */
public final class ShiftGlowHud {
    private ShiftGlowHud() {}

    private static final int RGB = 0xFFC81E;
    private static final int STRIPS = 14;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.gameRenderer == null) return;

        // The whole world goes golden-amber with dark amber edges, in every perspective.
        float world = ShiftBallManager.worldTintLevel();
        if (world > 0.01f) renderWorldTint(ctx, mc, world);

        if (!ShiftBallConfig.enabled || !ShiftBallConfig.glow || !ShiftBallConfig.glowScreen
                || mc.gameRenderer.getCamera().isThirdPerson()) return;
        float level = ShiftBallManager.glowLevel(mc.player.getId());
        if (level <= 0.02f) return;

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();

        // Warm tint over everything.
        ctx.fill(0, 0, w, h, argb(0.26f * level, RGB));

        // Brighter edges, fading towards the middle.
        int band = Math.round(Math.min(w, h) * 0.30f);
        int step = Math.max(1, band / STRIPS);
        for (int i = 0; i < STRIPS; i++) {
            float f = 1f - i / (float) STRIPS;
            int c = argb(0.55f * level * f * f, RGB);
            int o = i * step;
            ctx.fill(0, o, w, o + step, c);                 // top
            ctx.fill(0, h - o - step, w, h - o, c);         // bottom
            ctx.fill(o, 0, o + step, h, c);                 // left
            ctx.fill(w - o - step, 0, w - o, h, c);         // right
        }
    }

    private static void renderWorldTint(DrawContext ctx, MinecraftClient mc, float level) {
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        ctx.fill(0, 0, w, h, argb(0.36f * level, 0xFFB000));            // golden-amber wash
        int band = Math.round(Math.min(w, h) * 0.38f);
        int step = Math.max(1, band / STRIPS);
        for (int i = 0; i < STRIPS; i++) {
            float f = 1f - i / (float) STRIPS;
            int c = argb(0.50f * level * f * f, 0x5A2800);              // dark amber, like the anime's edges
            int o = i * step;
            ctx.fill(0, o, w, o + step, c);
            ctx.fill(0, h - o - step, w, h - o, c);
            ctx.fill(o, 0, o + step, h, c);
            ctx.fill(w - o - step, 0, w - o, h, c);
        }
    }

    private static int argb(float alpha, int rgb) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | rgb;
    }
}
