package dev.shiftball.core;

/** Light levels and world-tint strength for the transformation. Pure Java so it can be tested. */
public final class LightMath {
    private LightMath() {}

    /** Light level (0..max) given out by a charging-up body; {@code level01} is the glow level 0..1. */
    public static int glowLight(float level01, int max) {
        if (max <= 0 || level01 <= 0.02f) return 0;
        int v = Math.round(Math.max(0f, Math.min(1f, level01)) * max * 0.75f);
        return Math.max(1, Math.min(max, v));
    }

    /** Light level of the transformation ball: quick ramp up, full for most of it, dies down at the end. */
    public static int ballLight(float ageTicks, float durationTicks, int max) {
        if (max <= 0 || durationTicks <= 0f) return 0;
        float p = Math.max(0f, Math.min(1f, ageTicks / durationTicks));
        float ramp = Math.min(1f, ageTicks / 6f);
        float out = 1f - BallMath.smoothstep(0.80f, 1.0f, p);
        return Math.max(0, Math.min(max, Math.round(max * ramp * out)));
    }

    /** How strongly the world is tinted gold while charging up: nothing at first, full near the transformation. */
    public static float preshiftWorldTint(float ageTicks, float durationTicks) {
        return BallMath.smoothstep(0.30f, 1.0f, GlowMath.progress(ageTicks, durationTicks));
    }

    /** World tint while a ball is out: full for the first half, gone by the end. */
    public static float ballWorldTint(float ageTicks, float durationTicks) {
        float p = GlowMath.progress(ageTicks, durationTicks);
        return Math.min(1f, ageTicks / 6f) * (1f - BallMath.smoothstep(0.55f, 1.0f, p));
    }

    /** Fades the tint of a ball with distance: full within 8 blocks, none beyond 88. */
    public static float distanceFactor(double distance) {
        return (float) Math.max(0.0, Math.min(1.0, 1.0 - (distance - 8.0) / 80.0));
    }
}
