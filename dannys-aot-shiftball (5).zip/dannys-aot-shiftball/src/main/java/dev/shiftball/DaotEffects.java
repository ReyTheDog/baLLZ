package dev.shiftball;

import java.lang.reflect.Method;

/**
 * Calls the mod's own "stop effect" methods by name (reflection, so the addon does not need the mod to
 * compile). Danny's AoT ends the preshift lightning itself when a PLAYER's titan appears, but for a
 * villager's titan it lets the lightning run on, next to the new ball.
 */
final class DaotEffects {
    private DaotEffects() {}

    private static boolean resolved = false;
    private static Method stopPreshift;
    private static Method stopShift;

    static void stopPreshiftAndShift() {
        if (!resolved) {
            resolved = true;
            try {
                Class<?> helper = Class.forName("daot.ShiftParticleHelper");
                stopPreshift = helper.getMethod("stopPreshiftEffect");
                stopShift = helper.getMethod("stopShiftEffect");
            } catch (Throwable t) {
                ShiftBallClient.LOGGER.warn("Could not find the mod's effect-stop methods: {}", t.toString());
            }
        }
        call(stopPreshift);
        call(stopShift);
    }

    private static void call(Method m) {
        if (m == null) return;
        try {
            m.invoke(null);
        } catch (Throwable t) {
            ShiftBallClient.LOGGER.warn("Stopping the mod's effect failed: {}", t.toString());
        }
    }
}
