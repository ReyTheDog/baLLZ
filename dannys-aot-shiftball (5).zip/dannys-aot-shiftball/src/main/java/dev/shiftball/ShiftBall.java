package dev.shiftball;

import net.minecraft.util.math.Vec3d;

/** One active transformation ball. Client thread only. */
final class ShiftBall {
    final int entityId;
    final long startNanos;
    final float durationTicks;
    final long seed;
    /** True for the villager's preshift ball: it keeps going (at the last known spot) after the villager is gone. */
    final boolean keepWhenRemoved;
    /** True for the ball of a villager's pure titan (it hides the mod's other effects while it lasts). */
    boolean pure = false;

    /** Largest radius seen so far, so the ball never shrinks below the titan while it emerges. */
    float maxRadius = 0f;
    Vec3d lastCenter;
    boolean dead = false;
    boolean logged = false;

    ShiftBall(int entityId, Vec3d fallbackCenter, float durationTicks, long seed, boolean keepWhenRemoved) {
        this.entityId = entityId;
        this.lastCenter = fallbackCenter;
        this.durationTicks = durationTicks;
        this.seed = seed;
        this.keepWhenRemoved = keepWhenRemoved;
        this.startNanos = System.nanoTime();
    }

    float ageTicks(long nowNanos) {
        return (nowNanos - startNanos) / 50_000_000f;
    }
}
