package dev.shiftball.core;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Dependency-free checks for the pure logic. Run: java dev.shiftball.core.CoreCheck */
public final class CoreCheck {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        if (!ok) failures++;
    }

    private static double len(float[] a, int i) {
        return Math.sqrt(a[i * 3] * a[i * 3] + a[i * 3 + 1] * a[i * 3 + 1] + a[i * 3 + 2] * a[i * 3 + 2]);
    }

    public static void main(String[] args) throws Exception {
        // ---- Config (first, while the static fields still hold their defaults) ----
        Path dir = Files.createTempDirectory("shiftball-check");
        Path old = dir.resolve("old.properties");
        Files.writeString(old, "configVersion=2\narcCount=6\narcWidth=1.0\nminPulse=0.65\nsparkCount=40\ncoverRadius.cart_shifter_titan=9\n");
        ShiftBallConfig.load(old);
        check(ShiftBallConfig.arcCount == 10 && ShiftBallConfig.arcWidth == 1.5f && ShiftBallConfig.minPulse == 0.75f
                        && ShiftBallConfig.sparkCount == 60 && ShiftBallConfig.beams == 6 && ShiftBallConfig.surfaceArcs == 8
                        && ShiftBallConfig.surfaceSparks == 30,
                "an old-version config is replaced by the new defaults once (more lightning, beams on)");
        check(!ShiftBallConfig.pureTitanPreshiftBall && ShiftBallConfig.pureTitanPreshiftDuration == 40f, "villager keeps the original lightning by default (no preshift ball)");
        check(ShiftBallConfig.glow && ShiftBallConfig.glowPlayers && ShiftBallConfig.glowVillagers && ShiftBallConfig.glowIntensity == 3f, "glow is on by default");
        check(ShiftBallConfig.coverOverrides.isEmpty(), "old-version overrides are dropped with it");
        check(Files.readString(old).contains("configVersion=" + ShiftBallConfig.CONFIG_VERSION), "config is rewritten with the current version");

        Path cur = dir.resolve("cur.properties");
        Files.writeString(cur, "configVersion=" + ShiftBallConfig.CONFIG_VERSION + "\nminPulse=5\npulseHz=abc\narcCount=3\nenabled=false\n"
                + "coverRadius.Cart_Shifter_Titan=5.5\ncoverRadius.bad=xyz\n");
        ShiftBallConfig.load(cur);
        check(ShiftBallConfig.minPulse == 1f, "config clamps out-of-range values");
        check(ShiftBallConfig.pulseHz == 3.6f, "config falls back to default on garbage");
        check(ShiftBallConfig.arcCount == 3 && !ShiftBallConfig.enabled, "config reads valid values");
        check(ShiftBallConfig.coverOverrides.size() == 1 && ShiftBallConfig.coverOverrides.get("cart_shifter_titan") == 5.5f,
                "per-titan cover override is read (id lower-cased, garbage skipped)");
        check(Files.readString(cur).contains("coverRadius.cart_shifter_titan=5.5") && Files.readString(cur).contains("sparkCount="),
                "config writes overrides and missing keys back");
        ShiftBallConfig.enabled = true;
        ShiftBallConfig.minPulse = 0.75f;

        // ---- Preshift glow ----
        for (float dur : new float[] {80f, 40f}) {
            float prev = -1f;
            boolean mono = true;
            for (float a = 0f; a <= dur; a += 0.25f) {
                float v = GlowMath.base(a, dur);
                if (v < prev - 1e-6f) mono = false;
                prev = v;
            }
            check(mono, "glow base never gets dimmer as the transformation nears (D=" + dur + ")");
            check(GlowMath.base(dur, dur) > 0.99f && GlowMath.base(0f, dur) < 0.15f, "glow goes from faint to full (D=" + dur + ")");
            check(GlowMath.brightness(dur * 0.9f, dur) > 2.5f * GlowMath.brightness(dur * 0.1f, dur), "glow is much brighter near the end (D=" + dur + ")");
            boolean inRange = true;
            for (float a = 0f; a <= dur * 1.2f; a += 0.1f) {
                float v = GlowMath.brightness(a, dur);
                if (v < 0f || v > 1.2f) inRange = false;
            }
            check(inRange, "glow brightness stays within 0..1.2 (D=" + dur + ")");
        }
        int white = 0xFFFFFFFF;
        check(GlowMath.tintColor(white, 0f) == white && GlowMath.tintColor(0x80ABCDEF, 0f) == 0x80ABCDEF, "no glow leaves the colour alone");
        int gold = GlowMath.tintColor(white, 1f);
        check(((gold >>> 24) & 255) == 255 && ((gold >> 16) & 255) == 255 && ((gold >> 8) & 255) == 204 && (gold & 255) == 46,
                "full glow turns white into golden yellow (255,204,46), alpha kept");
        boolean greener = true;
        for (float t = 0f; t < 1f; t += 0.05f) {
            int c1 = GlowMath.tintColor(white, t), c2 = GlowMath.tintColor(white, t + 0.05f);
            if ((c2 & 255) > (c1 & 255) || ((c2 >> 8) & 255) > ((c1 >> 8) & 255)) greener = false;
        }
        check(greener, "blue channel only ever falls as the glow rises (yellower and yellower)");
        check(GlowMath.tintColor(0x80FFFFFF, 1f) >>> 24 == 0x80, "translucent colours keep their alpha");
        int dark = (3 << 20) | (2 << 4);
        check(GlowMath.tintLight(dark, 0f) == dark && GlowMath.tintLight(dark, 1f) == ((15 << 20) | (15 << 4)), "full glow lights the body at full brightness, none leaves the light alone");
        int mid = GlowMath.tintLight(dark, 0.5f);
        check(((mid >> 20) & 15) > 3 && ((mid >> 20) & 15) < 15 && ((mid >> 4) & 15) > 2, "half glow is brighter than the surroundings but not full");
        check(GlowMath.fade(0f, 4f) == 1f && GlowMath.fade(2f, 4f) == 0.5f && GlowMath.fade(5f, 4f) == 0f, "glow fades out over 4 ticks");

        // ---- Light and world tint ----
        check(LightMath.glowLight(0f, 15) == 0 && LightMath.glowLight(0.05f, 15) >= 1, "no glow gives no light, a faint one gives at least 1");
        int prevLight = 0; boolean monoLight = true;
        for (float lv = 0.05f; lv <= 1f; lv += 0.05f) { int v = LightMath.glowLight(lv, 15); if (v < prevLight) monoLight = false; prevLight = v; }
        check(monoLight && LightMath.glowLight(1f, 15) >= 10 && LightMath.glowLight(1f, 15) <= 15, "charging-up light grows with the glow and reaches ~11 (max 15)");
        check(LightMath.glowLight(1f, 0) == 0 && LightMath.ballLight(40f, 80f, 0) == 0, "max 0 turns the light off");
        check(LightMath.ballLight(0f, 80f, 15) == 0 && LightMath.ballLight(40f, 80f, 15) == 15 && LightMath.ballLight(80f, 80f, 15) == 0, "ball light starts dark, is full in the middle, is gone at the end");
        boolean inRangeLight = true;
        for (float a = 0f; a <= 80f; a += 0.5f) { int v = LightMath.ballLight(a, 80f, 15); if (v < 0 || v > 15) inRangeLight = false; }
        check(inRangeLight, "ball light stays within 0..15");
        check(LightMath.preshiftWorldTint(0f, 80f) == 0f && LightMath.preshiftWorldTint(80f, 80f) == 1f && LightMath.preshiftWorldTint(16f, 80f) == 0f,
                "world tint is absent early in the charge-up and full at the transformation");
        check(LightMath.preshiftWorldTint(70f, 80f) > LightMath.preshiftWorldTint(50f, 80f), "world tint keeps growing near the end");
        check(LightMath.ballWorldTint(40f, 80f) == 1f && LightMath.ballWorldTint(80f, 80f) == 0f, "world tint is full during the ball and gone at its end");
        check(LightMath.distanceFactor(5) == 1f && LightMath.distanceFactor(200) == 0f && LightMath.distanceFactor(48) > 0f && LightMath.distanceFactor(48) < 1f, "ball tint fades with distance");
        // ---- Pulse shape ----
        for (float duration : new float[] {80f, 95f, 40f}) {
            check(BallMath.scale(0f, duration, 0.65f, 1.6f) == 0f, "scale is 0 at start (D=" + duration + ")");
            check(BallMath.scale(duration, duration, 0.65f, 1.6f) == 0f, "scale is 0 at end (D=" + duration + ")");
            float max = 0f;
            boolean nonNegative = true;
            for (float a = 0.25f; a < duration; a += 0.25f) {
                float s = BallMath.scale(a, duration, 0.65f, 1.6f);
                max = Math.max(max, s);
                if (s < 0f) nonNegative = false;
            }
            check(nonNegative, "scale never negative (D=" + duration + ")");
            check(max <= 1.026f && max >= 0.95f, "ball reaches ~full size and not beyond (max=" + max + ", D=" + duration + ")");
        }
        int risings = 0;
        boolean high = false, started = false;
        for (float a = 0.1f * 80f; a < 0.88f * 80f; a += 0.1f) {
            float s = BallMath.scale(a, 80f, 0.6f, 1.6f);
            if (s > 0.84f && !high) { if (started) risings++; high = true; started = true; }
            if (s < 0.76f) high = false;
        }
        check(risings >= 3, "it keeps shrinking and growing: at least 4 pulses in a normal shift (risings=" + risings + ")");

        // ---- Mesh ----
        SphereMesh mesh = new SphereMesh(18, 12);
        check(mesh.quadCount == 216 && mesh.quads.length == 216 * 12, "sphere mesh has 216 quads");
        boolean unit = true;
        for (int i = 0; i < mesh.quads.length / 3; i++) if (Math.abs(len(mesh.quads, i) - 1.0) > 1e-5) unit = false;
        check(unit, "every sphere vertex lies on the unit sphere");

        double inradius = Double.MAX_VALUE;
        float[] cq = mesh.quads;
        for (int i = 0; i < mesh.quadCount; i++) {
            int o = i * 12;
            double d1x = cq[o + 6] - cq[o], d1y = cq[o + 7] - cq[o + 1], d1z = cq[o + 8] - cq[o + 2];
            double d2x = cq[o + 9] - cq[o + 3], d2y = cq[o + 10] - cq[o + 4], d2z = cq[o + 11] - cq[o + 5];
            double nx = d1y * d2z - d1z * d2y, ny = d1z * d2x - d1x * d2z, nz = d1x * d2y - d1y * d2x;
            double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1e-9) continue;
            inradius = Math.min(inradius, Math.abs((nx * cq[o] + ny * cq[o + 1] + nz * cq[o + 2]) / nl));
        }
        check(inradius * BallMath.TESSELLATION >= 1.0, "outer shell scaled by TESSELLATION never dips inside the covering radius (inradius=" + inradius + ")");

        // ---- Coverage of every titan hitbox (width, height) in Danny's AoT 2.5.2 ----
        // shifters: attack/armored, female, ogre, test (= Jaw), cart, colossal; pure: small/medium sizes
        double[][] hitboxes = {{0.6, 1.95}, {2.3, 15}, {2.1, 14}, {1.7, 10}, {0.8, 5.5}, {1.6, 4.0}, {9.3, 60}, {0.7, 4}, {1.0, 6}, {1.5, 8}, {2.0, 12}};
        float cov = ShiftBallConfig.coverage, reach = ShiftBallConfig.smallReach;
        for (double[] hb : hitboxes) {
            double w = hb[0], h = hb[1];
            for (float minPulse : new float[] {0.75f, 0.5f}) {
                for (float duration : new float[] {80f, 95f, 40f}) {
                    float cover = BallMath.coverRadius(w, h, w, cov, 1.0f, reach);
                    float full = BallMath.fullRadius(cover, minPulse);
                    double needed = BallMath.inflatedHalfDiagonal(w, h, w, reach); // far corner of the widened hitbox
                    double lowest = Double.MAX_VALUE;
                    for (float a = 0.09f * duration; a <= duration * 0.88f; a += 0.1f) {
                        double r = full * BallMath.scale(a, duration, minPulse, 1.6f) * BallMath.TESSELLATION * inradius;
                        lowest = Math.min(lowest, r);
                    }
                    check(lowest >= needed, String.format("%.1fx%.1f titan (minPulse %.2f, D=%.0f) covered from 9%%..88%%: shell inner edge %.2f >= far corner %.2f",
                            w, h, minPulse, duration, lowest, needed));
                }
            }
        }
        double cartOld = 0.5 * Math.sqrt(1.6 * 1.6 * 2 + 16) * 1.1;
        double jawOld = 0.5 * Math.sqrt(0.8 * 0.8 * 2 + 5.5 * 5.5) * 1.1;
        float cartNew = BallMath.coverRadius(1.6, 4.0, 1.6, cov, 1f, reach);
        float jawNew = BallMath.coverRadius(0.8, 5.5, 0.8, cov, 1f, reach);
        check(cartNew > cartOld * 1.5, String.format("Cart titan ball is now much bigger (%.2f -> %.2f blocks)", cartOld, cartNew));
        check(jawNew > jawOld * 1.4, String.format("Jaw titan ball is now much bigger (%.2f -> %.2f blocks)", jawOld, jawNew));
        check(BallMath.coverRadius(2.3, 15, 2.3, cov, 1f, reach) == (float) (0.5 * Math.sqrt(2.3 * 2.3 * 2 + 225) * cov),
                "tall titans (Attack/Armored 15 blocks) keep exactly the size you said was nearly perfect");
        check(BallMath.coverRadius(2.1, 14, 2.1, cov, 1f, reach) == (float) (0.5 * Math.sqrt(2.1 * 2.1 * 2 + 196) * cov),
                "Female titan size unchanged");

        // ---- Lightning ----
        float[] arc = LightningArcs.arc(12345L, 8f, 6f, 7);
        check(arc.length == 8 * 3, "arc has segments+1 points");
        check(Math.abs(len(arc, 0) - 8f) < 1e-4, "arc starts exactly on the ball surface (r0=" + len(arc, 0) + ")");
        check(len(arc, 7) > 8f + 2f, "arc ends well outside the ball (r=" + len(arc, 7) + ")");
        check(Arrays.equals(arc, LightningArcs.arc(12345L, 8f, 6f, 7)), "arcs are deterministic per seed");
        check(!Arrays.equals(arc, LightningArcs.arc(12346L, 8f, 6f, 7)), "different seeds give different arcs");

        float[] fork = LightningArcs.branch(99L, arc, 3, 3f, 4);
        check(fork.length == 5 * 3 && fork[0] == arc[9] && fork[1] == arc[10] && fork[2] == arc[11], "fork starts exactly on its parent bolt");
        check(Arrays.equals(fork, LightningArcs.branch(99L, arc, 3, 3f, 4)), "forks are deterministic");

        boolean onSphere = true, moves = true;
        for (long s = 1; s <= 50; s++) {
            float[] sa = LightningArcs.surfaceArc(s, 9f, 9);
            for (int i = 0; i <= 9; i++) if (Math.abs(len(sa, i) - 9f) > 1e-3) onSphere = false;
            for (int i = 0; i < 9; i++) {
                double dx = sa[i * 3 + 3] - sa[i * 3], dy = sa[i * 3 + 4] - sa[i * 3 + 1], dz = sa[i * 3 + 5] - sa[i * 3 + 2];
                if (Math.sqrt(dx * dx + dy * dy + dz * dz) < 0.2) moves = false;
            }
        }
        check(onSphere, "surface lightning stays on the ball surface (50 random bolts)");
        check(moves, "surface lightning advances at every step");

        boolean sparkOk = true;
        for (float t = 0f; t <= 1.0001f; t += 0.1f) {
            float[] sp = LightningArcs.spark(777L, 9f, t);
            double head = Math.sqrt(sp[0] * sp[0] + sp[1] * sp[1] + sp[2] * sp[2]);
            double tail = Math.sqrt(sp[3] * sp[3] + sp[4] * sp[4] + sp[5] * sp[5]);
            if (head < 9f - 1e-4 || tail < 9f - 1e-4 || tail > head + 1e-4) sparkOk = false;
        }
        check(sparkOk, "sparks start at the ball, fly outward, and the tail trails behind the head");

        // ---- Lightning strips must face the camera (the vanilla lightning layer culls back faces) ----
        java.util.Random rnd = new java.util.Random(2024);
        int bad = 0, total = 0, degenerate = 0;
        double minWidthErr = 0;
        for (int i = 0; i < 20000; i++) {
            float ox = (rnd.nextFloat() - 0.5f) * 80f, oy = (rnd.nextFloat() - 0.5f) * 80f, oz = (rnd.nextFloat() - 0.5f) * 80f;
            float[] p = new float[6];
            for (int k = 0; k < 6; k++) p[k] = (rnd.nextFloat() - 0.5f) * 12f;
            float half = 0.05f + rnd.nextFloat() * 0.3f;
            float[] v = Billboard.strip(p[0], p[1], p[2], p[3], p[4], p[5], ox, oy, oz, half);
            if (v == null) { degenerate++; continue; }
            total++;
            // normal of each winding; the camera is at (-ox,-oy,-oz); view vector = quad centre - camera
            int facing = 0;
            for (int w = 0; w < 2; w++) {
                int o = w * 12;
                double e1x = v[o + 3] - v[o], e1y = v[o + 4] - v[o + 1], e1z = v[o + 5] - v[o + 2];
                double e2x = v[o + 6] - v[o + 3], e2y = v[o + 7] - v[o + 4], e2z = v[o + 8] - v[o + 5];
                double nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
                double cx = (v[o] + v[o + 3] + v[o + 6] + v[o + 9]) / 4 + ox, cy = (v[o + 1] + v[o + 4] + v[o + 7] + v[o + 10]) / 4 + oy,
                        cz = (v[o + 2] + v[o + 5] + v[o + 8] + v[o + 11]) / 4 + oz;
                // counter-clockwise as seen from the camera <=> normal points towards the camera <=> normal . view < 0
                if (nx * cx + ny * cy + nz * cz < 0) facing++;
            }
            if (facing != 1) bad++;
            double wx = v[3] - v[0], wy = v[4] - v[1], wz = v[5] - v[2];
            minWidthErr = Math.max(minWidthErr, Math.abs(Math.sqrt(wx * wx + wy * wy + wz * wz) - 2 * half));
        }
        check(total > 19000 && bad == 0, "every lightning strip has exactly one winding facing the camera (" + total + " random strips, " + bad + " bad)");
        check(minWidthErr < 1e-3, "strips have the requested width (max error " + minWidthErr + ")");
        // And prove the old single-winding strip would have been invisible: its normal pointed away from the camera.
        float[] one = Billboard.strip(0f, 0f, 10f, 0f, 1f, 10f, 0f, 0f, 0f, 1f);
        double e1z = 0, nzOld;
        {
            double e1x = one[3] - one[0], e1y = one[4] - one[1];
            double e2x = one[6] - one[3], e2y = one[7] - one[4];
            nzOld = e1x * e2y - e1y * e2x; // z component of the normal of the first winding
        }
        check(nzOld > 0, "(regression) the first winding of a strip 10 blocks ahead points away from the camera, so the old one-winding strips were culled");

        System.out.println(failures == 0 ? "\nALL CHECKS PASSED" : "\n" + failures + " CHECK(S) FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
